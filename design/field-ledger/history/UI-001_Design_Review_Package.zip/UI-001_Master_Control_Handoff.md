# SỔ NÔNG DÂN — UI-001 / Product Design Foundation

**Version:** 0.1 concept review · 2026-11-27 · **PROPOSED / OWNER REVIEW PENDING**

Repository `hnhuynh1003-blip/so-nong-dan`, baseline branch supplied `checkpoint/cp-001-r2`, pinned Owner Acceptance Record HEAD `3ae5e2be06e401adaca044aad6f9376e9b15e5c5`. GitHub tree at that exact SHA read successfully (not truncated); live branch endpoint rejected URL, so live branch tip not independently established. No writes. CP-001 ACCEPTED; CP-002 SPECIFICATION AUTHORIZED, IMPLEMENTATION NOT AUTHORIZED; D08–D12 OPEN. UI-002–007 not started. No Codex, CI, merge, deploy, repository code changes or real data. This is a handoff artifact for Master Control review, not an acceptance record.

## 1. Source and traceability

Read at pinned SHA: `docs/01_MASTER_SPECIFICATION.md` (blob `230d8aedea24b1c1d11585eb5b40374a92d2312b`), `03_SYSTEM_ARCHITECTURE.md`, `04_DATA_MODEL.md`, `05_CALCULATION_CONTRACT.md`, `09_DECISION_LOG.md`, `10_PROJECT_STATUS.md`, `12_R1_DOMAIN_CONTRACTS.md`, `13_INVARIANT_REGISTER.md`, ADR 0002/0003, README, Owner Acceptance record and `src/shell/routes.ts` plus six module boundaries. Master §7 requires five home shortcuts; §5–6 requires basis, quality, provenance and no duplicate recognition; §8 requires separate local/sync/backup states. R1 supplements distinguish per-dimension allocation, immutable rounding policy, financial subjects, source revision. Architecture remains independent of UI. No authoritative business rule is changed. Some data model/invariant text read in excerpts; do not interpret this design review as a complete technical audit.

## 2. Three visual directions

| Concept | Priorities | Navigation | Design language | Trade-off |
|---|---|---|---|---|
| A — Đồng xanh | Five shortcuts first, full-width rice weighing, then recorded figures and review | Trang chủ / Sản xuất / Ghi nhanh / Tài chính / Dữ liệu | Forest green, warm ivory, large primary action; Inter / Noto Sans; 18 px cards | Financial detail requires one more tap, rice dominates seasonally |
| B — Sổ tài chính | Recorded revenue/cost vs receipts, paid and known receivable, then shortcuts | Trang chủ / Tài chính / Ghi nhanh / Sản xuất / Dữ liệu | Navy and teal, cool surface, compact 13 px cards, Inter / Noto Sans | Higher number density; less immediate entry |
| C — Nhật ký mùa vụ | Period, agricultural identity, chronological source-linked activity, then shortcuts | Trang chủ / Nhật ký / Ghi nhanh / Tài chính / Dữ liệu | Terracotta, warm cream, 20 px cards, Noto Serif headings + Inter | Timeline needs filtering and pagination; journal could feel slower for entry |

Recommendation: choose A as global visual direction and navigation; consider B's separated financial metric pattern within future finance/report pages and C's source-linked timeline within data/farm pages, using A's tokens. Do not blend three palettes; user selects A/B/C. All mockups are concepts for UI-001, not full UI-002 dashboard specifications. Prototype only opens preview dialogs, changes synthetic period, and switches concept. No transaction fields, calculation, save, posting, persistence, sync, actual module navigation or source images implemented. Header leaf symbol is provisional, not approved brand. Fixed rice priority is a visual proposal only; season-aware customization requires later owner review, never inferred by an unapproved season rule.

## 3. Information architecture / navigation

Proposed A, mobile: Trang chủ (overview + 5 entry points); Sản xuất (Cân lúa, Bán tôm/cua, Chi phí, Đất / thuê); Ghi nhanh (action chooser, not a domain or route); Tài chính (Quyết toán, thu/chi, công nợ, tài khoản, vay, tài sản, báo cáo); Dữ liệu (nhập sổ cũ, nguồn/chứng từ, chất lượng, lịch sử, xuất/backup, thiết lập accessible separately from entry flows). Analytics reached via Tài chính / Quyết toán and filters; data provenance reachable from every reported figure. This is a navigation grouping proposal, not a schema or URL change. No household switch, signup or SaaS administration. Existing route alignment: Cân lúa → `can-lua`; Bán tôm/cua → `ban-tom-cua`; Ghi chi phí → `chi-phi`; Đất → `dat`; Quyết toán → `quyet-toan`; Nhập sổ cũ → `nhap-du-lieu`. New sections are conceptual aggregators; Master Control to approve grouping and route strategy. Existing route paths preserved.

### User flows (concept level)

- Field: home → Cân lúa → chọn/tiếp tục nhóm hoặc phiếu nháp → nhập → xem tổng/giảm trừ → rà soát đủ điều kiện → chốt only if policy approval and source requirements met. UI-003 deferred. No implicit rounding or input order/color.
- Sale: home → bán tôm/cua → ngày HOẶC kỳ + số tiền → optional species/grade/weight/price/land/lines + source → verify → later record receipt or payment separately. No invented sale lines or guessed settlement.
- Cost: home → ghi chi phí → date/period + amount + classification (including shared) → source + verification → review. No required land allocation; do not double count shared cost or rent cash vs allocated cost.
- Historical: home → nhập sổ cũ → preview/mapping → verify duplicate, aggregate overlap and row errors → owner review → import or rollback as later authorized. Original source preserved.
- Report: home → quyết toán → explicit basis/filter → metric quality → drill down to source record/revision/policy/attachments. If overlap unresolved or coverage material unknown, block complete conclusion.
- Pending/conflict: show local saved only after durable commit, show not synced separately; retry, conflict review, source revision; no automatic overwrite. Backup separately dated and not inferred from sync.

## 4. Design tokens / proposed foundation

| Token | A | B | C |
|---|---|---|---|
| Background | #F5F6EE | #F1F4F7 | #FAF5EA |
| Surface | #FFFFFF | #FFFFFF | #FFFDF8 |
| Text | #1D3025 | #152A3D | #392F25 |
| Muted | #53665A | #526477 | #6D5C4B |
| Primary | #205B40 | #08645C | #904E34 |
| Primary soft | #E2EDE1 | #DCEEEA | #F2E2D5 |
| Hero | #174B35 | #172C43 | #F0E6D3 |
| Border | #DCE3D9 | #D9E1E9 | #E8DED0 |
| Warning text | #8A4D11 | #83510D | #864B12 |
| Warning surface | #FFF0D6 | #FFF1D9 | #FFF0D1 |
| Radius card | 18px | 13px | 20px |

Typography target: Inter with Noto Sans fallback and Vietnamese coverage, tabular numerals, amount 28–36 px/700–800, page 24–28/700, section 18–20/650–700, action 16/650, body 16/400–500, secondary 14/500, metadata 12–13 (not essential). C uses Noto Serif headings only, all input/data uses sans. Prototype has smaller metadata/action labels at narrow widths; tune to targets before production. Local fonts/fallback; no distributed font files and no remote requests. Final font licensing/availability and offline packaging to be reviewed. Space: 4/8/12/16/24/32 px; layout gutters 16, larger viewport 24. Radius control 12, card token, sheet 22. Icons 20–24 outline; always label. Numbers locale vi-VN, currency VND as đ, no compact number without access to full value, preserve exact display vs calculation, no assumed conversion of công đất. Avoid color-only profit/gain meaning or legacy rice color semantics.

Semantic state proposals (independent from data model): success #21633F / #E3F1E6; caution #8A4D11 / #FFF0D6; error/conflict #A72D29 / #FCE9E7; neutral #53665A / #E9EEE9; info #175B93 / #E5F0FA. Focus #1267C5. Only use semantic text + icon; colors not business values, not app-old cell semantics.

### Components and behavior

App header/period control; quick-action tile (primary/default/disabled/loading); navigation (active icon + label + indicator); amount card (basis, amount, explicit quality, drilldown); coverage notice; source/transaction row; status strip; dialog/sheet; section headers; list/filter/pagination; proposed field/numeric keypad, draft/revision notice, confirmation, destructive action, empty/loading/error/retry states for later module-specific work. Keep source, verification and coverage separate. Distinguish empty filter results from unknown coverage. UI cannot claim saved, confirmed or synced from button click alone. CTA to chốt absent/disabled until authorized and validated, not just visual blocking. No full screen flows implemented here.

### Responsive and accessibility

Mobile production design target: 320–599 px one column, quick grid two columns if labels fit, safe-area aware bottom navigation and sheet, target 48x48 px (minimum target 44x44 px), primary field actions 56–64px, avoid tiny inputs/scroll traps. Long content scrolls above bottom nav; keyboard does not cover primary action. 600–1023 px adaptive column layout, still same entry paths; ≥1024 px desktop sidebar, 12-column main area with list/detail and filters, exact numbers visible, keyboard focus and tab order; no loading all years/records into browser, query/pagination/export later. Actual prototype is comparison board (three columns above 1100px, single concept switcher below); not a desktop production screen. 4.5:1 body text, 3:1 large text and UI boundaries/focus as applicable, visible focus, explicit labels, screen-reader announced status, 200% zoom, no reliance on color, no unnecessary animations; test real phone outdoors, touch with wet/dirty hands as applicable, keyboard, large text, NVDA/VoiceOver and high-contrast. Contrast targets and all accessibility are not certified. Prototype has focus outlines, native dialog/Escape, native select, labels, text status, reduced-motion support, and no horizontal document overflow in sampled sizes; full WCAG/real device not tested. Bottom nav is at end of mockup, not sticky in demo.

## 5. Synthetic data and display integrity

All figures prewritten solely for comparison; no household figures or imported records. 2026 production cohort has partially covered data: recorded confirmed sample revenue 32,400,000 VND, recorded confirmed cost 12,800,000 VND, associated recorded receipts 26,400,000 VND, associated recorded payments 10,800,000 VND, known receivable 4,200,000 VND (independent observed sample amount, not revenue less cash). Receipt/payment metrics concern related production cohort, not a calendar-year cash flow report; detailed finance design must explicitly select both bases. 350,000 VND cost observation unverified excluded from confirmed cost sample; 2,400,000 VND sale sample confirmed for observation only, settlement unknown. Example records illustrative, not a full reconstructable ledger fixture. 2025 sample has unknown/no records — not actual 2025 family data. No total profit for partial period. No imputed balances, yield, assets, or data coverage percentages. In detail: `—` missing, `0 đ` only explicit confirmed-zero for correct scope, `Chưa xác nhận` source value pending, `Ước tính` separate non-posting, `Đã xác nhận` verification not full coverage. Sync demo status says not connected. No derived calculations or data model decisions.

## 6. Review checklist for Master Control (all pending)

- UI-IA: verify grouping and map to six existing boundaries; proposed additional aggregators must not cause schema changes or duplicate economic events.
- UI-QUALITY: verify labels and basis of recorded revenue/cost, cash, debt, unknown/estimated/confirmed and coverage; review sample independence; no authoritative aggregation with missing data.
- UI-D08/D10: no default rounding/method/tie/scope, no legacy order or color, no finalization without explicit approved policy; weigh UI only in UI-003.
- UI-D09/D12: no invented land area or công conversion, lease period, common-cost allocation, depreciation/valuation/inventory rules; unassigned/unknown visible.
- UI-D11: real phone/browser, font packaging, platform and budget unresolved. No external provider selected.
- UI-INTEGRITY: ensure UI follows immutable sources/revisions, atomic local + outbox, separate sync/backup, no forced settlement, no duplicate recognition, owner-only security. No UI claim of real storage.
- Owner decision: choose A, B, C, or request refinement. If A, review B and C patterns as subordinate patterns with same design tokens. Only after owner acceptance and Master Control review proceed to UI-002 within authorized design scope. No CP-002 implementation authorized. No A01–A12 test claims.

## 7. Artifacts and QA

`UI-001_Prototype.html` self-contained, opens locally in an ordinary modern browser (file launch not verified in this restricted sandbox). `UI-001_Three_Concepts.png` comparison render; `UI-001_Concept_A/B/C.png` full mock screens from 392 CSS px viewport cards (scrollable, not physical phone screenshots); `UI-001_Preview_Check.txt` local UI smoke output. Initial file:// navigation blocked by administrator; fallback injected exact HTML with Chromium Playwright page.set_content. Three desktop concepts: change year, D08/D10 rice intent, modal close; 390px concept tabs, quick chooser and nested sale preview/Escape; sampled viewport document-overflow checks; no browser JS errors. Screenshots inspected visually. No domain test or production verification, no independent verifier or real-device UAT; UI smoke only. Provide artifacts to Master Control through owner transfer; no direct cross-chat message sent. SHA256SUMS excludes itself. Design review not checkpoint acceptance.
