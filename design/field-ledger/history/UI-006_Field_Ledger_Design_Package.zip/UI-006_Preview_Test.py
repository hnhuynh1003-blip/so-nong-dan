from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
html=(p/'UI-006_Data_Vault.html').read_text()
log=[]
def make(b,w,h,src=html):
 page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1);page.set_default_timeout(3500);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(src,wait_until='load',timeout=7000);return page,errors
def check(page,errors):
 assert not errors,errors
 assert not page.evaluate('document.documentElement.scrollWidth>innerWidth'), 'horizontal overflow'
def shot(page,name):page.screenshot(path=str(p/name),timeout=5000,animations='disabled')
def act(page,a,where=''):page.locator((where+' ' if where else '')+f'[data-act={a}]').first.click()
def close(page):act(page,'close','#dialog')
def tab(page,t):page.locator(f'[data-tab={t}]').click()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],timeout=6000)
 log.append('Chromium '+b.version+'; page.set_content; standalone HTML; no install, no actual file URL or external service')
 for w,h in [(390,844),(320,700),(768,1024),(1280,720),(1440,900)]:
  page,errors=make(b,w,h);assert page.locator('#rows .row').count()==19
  for t in ['docs','imports','history','backup']:
   tab(page,t);check(page,errors)
   if t=='docs':shot(page,f'Vault_{w}.png')
   elif w in [390,1440]:shot(page,f'{t.capitalize()}_{w}.png')
  log.append(f'{w}x{h}: four tabs, no horizontal document overflow or page errors PASS');page.close()
 page,errors=make(b,390,844)
 act(page,'filter-review','#register');assert page.locator('#rows .row').count()==2 and page.locator('#filter').input_value()=='review'
 page.locator('#filter').select_option('all');page.locator('#query').fill('Phiếu bán mẫu 025');assert page.locator('#rows .row').count()==1
 page.locator('[data-item=s-r1]').click();assert 'Chưa có tệp đính kèm' in page.locator('#dbody').inner_text();shot(page,'Source_390.png');act(page,'enlarge','#dbody');assert 'MINH HỌA' in page.locator('#dbody').inner_text();act(page,'source','#dbody');act(page,'linked','#dbody');assert '7.800.000' in page.locator('#dbody').inner_text();act(page,'source','#dbody');close(page);assert page.locator('[data-item=s-r1]').evaluate('(e)=>e===document.activeElement');log.append('Search/filter, source facsimile explicitly not original, record link/back, focus restoration PASS')
 page.locator('#query').fill('');act(page,'add-source','#register');page.locator('[name=title]').fill('Sổ tay minh họa trang 13');page.locator('[name=attachment]').select_option('scan');act(page,'preview-source','#dbody');assert 'Không lưu' in page.locator('#result').inner_text();shot(page,'Add_Source_390.png');close(page);act(page,'add-source','#register');assert page.locator('[name=title]').input_value()=='Sổ tay minh họa trang 13';close(page);assert page.locator('#rows .row').count()==19;log.append('Add source metadata and sample attachment preview; in-session draft retained; fixture unchanged PASS')
 tab(page,'imports');act(page,'start-import','#register');act(page,'map','#dbody');shot(page,'Mapping_390.png');page.locator('[data-map=ngay]').select_option('source');act(page,'validate-map','#dbody');assert 'không trùng' in page.locator('#mapError').inner_text();page.locator('[data-map=ngay]').select_option('date');act(page,'validate-map','#dbody');assert page.locator('.resultline').count()==5;assert '1 trùng · 2 lỗi · 1 chồng phạm vi' in page.locator('#dbody').inner_text();shot(page,'Import_Review_390.png');page.locator('[data-act=row-detail][data-id="3"]').click();assert 'không cộng trực tiếp' in page.locator('#dbody').inner_text();shot(page,'Overlap_390.png');act(page,'results','#dbody');act(page,'import-review','#dbody');assert 'Không thực hiện commit' in page.locator('#dbody').inner_text();close(page);log.append('Import: fixture mapping, duplicate mapping rejected, five explicit review outcomes, overlap guard, no commit PASS (not real file parser/dedup)')
 tab(page,'history');page.locator('[data-hist=h3]').click();assert 'Chưa biết tình trạng' in page.locator('#dbody').inner_text();shot(page,'Revision_390.png');act(page,'source','#dbody');assert 'PT02' in page.locator('#dbody').inner_text();close(page);log.append('Synthetic revision before/after and source link PASS')
 tab(page,'backup');act(page,'export','#register');assert 'Tất cả năm' in page.locator('#dbody').inner_text();shot(page,'Export_390.png');close(page);act(page,'report-export','#register');page.locator('[name=format]').select_option('XLSX');act(page,'preview-export','#dbody');assert 'không tạo tệp' in page.locator('#result').inner_text();close(page);act(page,'restore','#register');page.locator('#restoreCase').select_option('bad');act(page,'restore-check','#dbody');assert 'Bị chặn' in page.locator('#result').inner_text();shot(page,'Restore_390.png');page.locator('#restoreCase').select_option('good');act(page,'restore-check','#dbody');assert 'Chưa thực hiện' in page.locator('#result').inner_text();close(page);log.append('Backup/export: distinct all-years vs report scope, mock checksum failure blocks simulated restore PASS (no actual checksums or backup)')
 tab(page,'docs');act(page,'states');page.locator('[data-state=error]').click();assert 'Không tải được' in page.locator('#rows').inner_text();act(page,'retry','#rows');assert page.locator('#rows .row').count()==19;page.locator('#year').select_option('2025');assert page.locator('#rows .row').count()==0 and 'Độ phủ chưa biết' in page.locator('#register').inner_text();shot(page,'Unknown_390.png');check(page,errors);page.close();log.append('List error/retry and unknown 2025 scope, no uncaught JavaScript errors PASS')
 for filename,section,kind in [('UI-004_Farm_Management_v0.2.html','Sản xuất','Farm'),('UI-005_Family_Finance_v0.2.html','Tài chính','Finance')]:
  src=(p/'revisions'/filename).read_text()
  for w,h in [(390,844),(320,700),(1440,900)]:
   page,errors=make(b,w,h,src);check(page,errors);assert page.locator('.header h1').get_attribute('class')=='sr';assert page.locator('.header h1').inner_text()==section;assert page.locator('#rows .row').count()>0
   if w!=320:shot(page,f'revisions/{kind}_{w}.png')
   page.close()
  log.append(f'{kind} compact heading revision: 3 viewports render, accessible section heading retained, rows present, no overflow PASS')
 b.close()
(p/'UI-006_QA.txt').write_text('\n'.join(log)+'\n');print('\n'.join(log))
