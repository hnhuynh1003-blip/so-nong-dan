from pathlib import Path
import re,json,hashlib,subprocess
OUT=Path(__file__).resolve().parent; ROOT=OUT/'sources' if (OUT/'sources').is_dir() else Path('/mnt/data')
paths={'home':'ui004/revisions/UI-002_Dashboard_v0.3.html','rice':'ui004/revisions/UI-003_Rice_Weighing_v0.3.html','farm':'ui006/revisions/UI-004_Farm_Management_v0.2.html','finance':'ui006/revisions/UI-005_Family_Finance_v0.2.html','vault':'ui006/UI-006_Data_Vault.html','analytics':'ui007/UI-007_Analytics.html'}
raw={k:(ROOT/p).read_text() for k,p in paths.items()}
arrays={}
for name in ('records','payments','accounts','assets'):
    pattern=rf'const {name}=(\[.*?\]);'
    literal=re.search(pattern,raw['finance'],re.S).group(1)
    arrays[name]=json.loads(subprocess.check_output(['node','-e',f'console.log(JSON.stringify({literal}))'],text=True))
    for k,s in raw.items():
        m=re.search(pattern,s,re.S)
        if not m: continue
        other=json.loads(subprocess.check_output(['node','-e',f'console.log(JSON.stringify({m.group(1)}))'],text=True))
        if k=='home' and name=='records': assert [{kk:vv for kk,vv in r.items() if kk!='activity'} for r in arrays[name]]==other
        else: assert other==arrays[name],(k,name)
        raw[k]=s[:m.start()]+f'const {name}=parent.UI008Fixtures.{name};'+s[m.end():]
# Preserve historical report-only sample and all module functions; only integrate routing and small shell changes.
css='''
/* UI-008 integration-only controls */
.u-back,.u-report,.u-link{min-height:44px;padding:8px 12px;border:1px solid var(--line,#d2dbd1);border-radius:5px;font:inherit;font-size:13px;font-weight:650;color:#205b40;background:#fff;cursor:pointer;text-align:center;white-space:nowrap}
.u-back:hover,.u-report:hover,.u-link:hover{background:#e2ede1}.u-back:focus-visible,.u-report:focus-visible,.u-link:focus-visible{outline:3px solid #1267c5;outline-offset:2px}
.u-back[hidden],.u-scope[hidden]{display:none!important}.u-back{flex:none}.u-scope{font-size:13px;padding:8px 10px;border-left:3px solid #8a4d11;background:#fff3df;color:#75410e;margin:0 0 12px}.u-scope button{font:inherit;font-weight:650;color:inherit;text-decoration:underline;min-height:44px;padding:4px 0;display:block}.u-deeplinks{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}.u-backicon{width:44px;min-width:44px;padding:0;font-size:22px;line-height:1}.u-dialog-back{margin-left:auto}.u-report{flex:none;background:transparent;border:0;text-decoration:underline;text-underline-offset:3px;padding:0 6px;font-size:13px}.u-fin-head{display:flex;align-items:center;gap:4px;flex-wrap:wrap}.u-brandwrap{display:flex;gap:8px;align-items:center;min-width:0}.u-brandwrap h1{margin:0}.u-scope + *{min-width:0}
@media(max-width:420px){.u-back{padding:6px 8px}.u-backicon{padding:0;width:44px}.u-brandwrap{gap:5px}.u-brandwrap h1{font-size:21px!important}}
'''
common=r'''
const U=parent.UI008, route=__ROUTE__;
const uQ=s=>document.querySelector(s), uModal=()=>uQ('dialog');
let uLastGlobal=null,uBack=false,uFocus=null;
function uButton(text, attrs, cls='u-link'){return `<button type="button" class="${cls}" ${attrs}>${text}</button>`}
function uScopeOptions(){const e=uQ('#year');if(!e)return;for(const v of ['2024','2023'])if(![...e.options].some(x=>x.value===v)){const o=document.createElement('option');o.value=o.textContent=v;e.append(o)}}
function uChrome(){
 uScopeOptions();let head=uQ('main header');if(!head)return;
 let b=uQ('.u-main-back');if(!b){b=document.createElement('button');b.type='button';b.className='u-back u-backicon u-main-back';b.dataset.uBack='1';b.setAttribute('aria-label','Quay lại');b.title='Quay lại';b.textContent='‹';if(route==='rice'){let h=head.querySelector('h1'),w=document.createElement('div');w.className='u-brandwrap';h.before(w);w.append(b,h)}else head.prepend(b)}b.hidden=!uBack;
 let modal=uModal(), dh=modal?.querySelector('.dhead,.dialogtitle');if(dh&&!dh.querySelector('.u-dialog-back')){let x=document.createElement('button');x.type='button';x.className='u-back u-backicon u-dialog-back';x.dataset.uBack='1';x.setAttribute('aria-label','Quay lại phân hệ trước');x.title='Quay lại phân hệ trước';x.textContent='‹';dh.querySelector('button')?.before(x)}if(dh?.querySelector('.u-dialog-back'))dh.querySelector('.u-dialog-back').hidden=!uBack;
 let sc=uQ('.u-scope');if(route!=='rice'&&route!=='analytics'){if(!sc){sc=document.createElement('div');sc.className='u-scope';head.after(sc)}sc.hidden=!['2023','2024'].includes(year);sc.innerHTML=sc.hidden?'':'Mẫu lịch sử '+year+' chỉ có trong báo cáo. '+uButton('Mở báo cáo ›','data-u-route="analytics"');}
 if(route==='finance'){let d=head.querySelector('.demo');if(d&&!head.querySelector('[data-u-route="analytics"]')){let w=document.createElement('div');w.className='u-fin-head';d.before(w);w.append(d);w.insertAdjacentHTML('beforeend',uButton('Báo cáo ›','data-u-route="analytics"','u-report'))}}
}
function uBefore(){uFocus=document.activeElement;}
function uRestore(){if(uFocus?.isConnected)uFocus.focus({preventScroll:true});else uQ('main')?.focus({preventScroll:true});}
function uRemember(){__REMEMBER__}
async function uClose(){let m=uModal();if(m?.open){uRemember();m.close();await new Promise(r=>setTimeout(r,35))}}
function uJump(to,params={}){U.navigate(to,params,true)}
function uAddLinks(id,kind){const b=uQ('#dbody');if(!b||!id||b.querySelector('.u-deeplinks'))return;let links='';if(U.hasSource(id))links+=uButton('Mở chứng từ ›',`data-u-source="${id}"`);if(kind==='prod')links+=uButton('Mở sổ sản xuất ›',`data-u-record="${id}"`);if(kind==='cash')links+=uButton('Mở thu chi ›',`data-u-payment="${id}"`);if(links)b.insertAdjacentHTML('beforeend',`<div class="u-deeplinks">${links}</div>`)}
async function uActivate(scope,opts={},isBack=false,canBack=false){
 uBack=canBack;let changing=false;
 if(route!=='rice'){uScopeOptions();const target=(route==='vault'&&year==='Tất cả'&&scope===uLastGlobal&&!opts.source&&!opts.tab&&!opts.action)?'Tất cả':scope;changing=year!==target;if(changing){await uClose();__SETYEAR__}uLastGlobal=scope;}
 if(!isBack&&(Object.keys(opts).length||!canBack))await uClose();
 __ACTIVATE__
 uChrome();if(isBack&&!changing)uRestore();else if(!opts.source&&!opts.record&&!opts.payment&&!opts.related&&!opts.action)window.scrollTo(0,0);
}
// Capture only cross-module navigation; the original module handlers retain local functionality.
document.addEventListener('click',e=>{let b=e.target.closest('button');if(!b)return;const take=()=>{e.preventDefault();e.stopImmediatePropagation()};
 if(b.dataset.uBack){take();U.back();return}
 if(b.dataset.nav){take();const n=b.dataset.nav;if(n==='quick'){U.quick();return}U.navigate(n==='data'?'vault':n,{},false);return}
 if(b.dataset.uRoute){take();uJump(b.dataset.uRoute);return}
 if(b.dataset.uSource){take();uJump('vault',{source:'s-'+b.dataset.uSource});return}
 if(b.dataset.uRecord){take();uJump('farm',{record:b.dataset.uRecord});return}
 if(b.dataset.uPayment){take();uJump('finance',{payment:b.dataset.uPayment});return}
 if(b.dataset.uRelated){take();uJump('finance',{related:b.dataset.uRelated});return}
 __CLICK__
},true);
if(route!=='rice')document.addEventListener('change',e=>{if(e.target.id==='year'){U.yearChanged(route,year,window);uChrome()}});
__WRAP__
uChrome();U.ready(route,{activate:uActivate,before:uBefore},window);
'''
configs={
'home':dict(REMEMBER='rememberForm();',SETYEAR="year=target;filter='all';query='';expanded=false;state='default';render();",ACTIVATE='',CLICK=r'''
 const a=b.dataset.action;if(['rice','sale','cost','import','report'].includes(a)){take();if(a==='rice')uJump('rice');else if(a==='sale'||a==='cost')uJump('farm',{action:a});else if(a==='import')uJump('vault',{tab:'imports',action:'start-import'});else uJump('analytics');return}
 if(b.dataset.record){take();uJump('farm',{record:b.dataset.record});return}
''',WRAP=''),
'rice':dict(REMEMBER='',SETYEAR='',ACTIVATE='',CLICK='',WRAP=''),
'farm':dict(REMEMBER='remember();',SETYEAR='year=target;switchTab(tab);',ACTIVATE=r'''
 if(opts.tab)switchTab(opts.tab);if(opts.record&&year==='2026'&&records.some(x=>x.id===opts.record)){switchTab('records');selected=opts.record;updateRows();let b=uQ(`[data-record="${selected}"]`);b?.scrollIntoView({block:'nearest'});b?.click();}if(opts.action){if(opts.action==='cost')switchTab('cost');else switchTab('records');form(opts.action)}
''',CLICK=r'''
 const a=b.dataset.act;if(a==='rice'){take();uJump('rice');return}if(a==='source'&&U.hasSource(b.dataset.id)){take();uJump('vault',{source:'s-'+b.dataset.id});return}
''',WRAP=r'''
 const uRD=recordDetail;recordDetail=function(r){let h=uRD(r);if(U.hasPayments(r.id))h=h.replace(/<\/div>$/,uButton('Các lần thanh toán ›',`data-u-related="${r.id}"`)+'</div>');return h};
 render();
'''),
'finance':dict(REMEMBER='remember();',SETYEAR="year=target;selected=null;query='';filter='all';listState='default';render();",ACTIVATE=r'''
 if(opts.tab)switchTab(opts.tab);if(opts.payment&&year==='2026'&&payments.some(x=>x.id===opts.payment)){switchTab('cashflow');selected=opts.payment;updateRows();let b=uQ(`[data-item="${selected}"]`);b?.scrollIntoView({block:'nearest'});b?.click();}if(opts.related&&year==='2026'&&records.some(x=>x.id===opts.related)){switchTab('debt');showRelated(opts.related)}if(opts.action)form(opts.action);
''',CLICK=r'''
 const a=b.dataset.act;if(a==='source'&&U.hasSource(b.dataset.id)){take();uJump('vault',{source:'s-'+b.dataset.id});return}
''',WRAP=r'''
 const uRender=render;render=function(){uRender();uChrome()};const uPD=paymentDetail;paymentDetail=function(x){let h=uPD(x);if(x.link&&records.some(r=>r.id===x.link))h=h.replace(/<\/div>$/,uButton('Mở giao dịch gốc ›',`data-u-record="${x.link}"`)+'</div>');return h};const uDD=debtDetail;debtDetail=function(r){return uDD(r).replace(/<\/div>$/,uButton('Mở sổ sản xuất ›',`data-u-record="${r.id}"`)+'</div>')};render();
'''),
'vault':dict(REMEMBER='remember();',SETYEAR='year=target;resetTab(tab);',ACTIVATE=r'''
 if(opts.tab)resetTab(opts.tab);if(opts.source&&byId(opts.source)&&year==='2026'){resetTab('docs');let b=uQ(`[data-item="${opts.source}"]`);b?.scrollIntoView({block:'nearest'});b?.click()}if(opts.action)showAction(opts.action);
''',CLICK=r'''
 const a=b.dataset.act;if(a==='linked'){let x=byId(b.dataset.id);if(x){take();uJump(x.kind==='cash'?'finance':'farm',x.kind==='cash'?{payment:x.record}:{record:x.record});return}}
''',WRAP=''),
'analytics':dict(REMEMBER='',SETYEAR='setYear(target,false);',ACTIVATE="if(opts.tab){tab=opts.tab;render()}",CLICK='',WRAP=r'''
 const uSY=setYear;setYear=function(y,focus){uSY(y,focus);U.yearChanged(route,year,window);uChrome()};const uSource=source;source=function(id){uSource(id);if(U.hasSource(id))uAddLinks(id,id.startsWith('r')?'prod':'cash');};
''')}
# Inject script at end of original single script; keep exact original CSS, structure, and task code.
docs={}
for k,s in raw.items():
    bridge=common.replace('__ROUTE__',json.dumps(k))
    for key,val in configs[k].items():bridge=bridge.replace('__'+key+'__',val)
    if k=='home':
        # Keep current scope options through original render (also uChrome on year change).
        s=s.replace('<option value="2025">2025</option>','<option value="2025">2025</option><option value="2024">2024</option><option value="2023">2023</option>')
        # Derive displayed shared totals from canonical samples, preserving previous labels and amounts.
        s=s.replace('const financial=()=>', '''const uiSums=(()=>{const rr=records.filter(r=>r.quality==='Đã xác nhận'),pp=parent.UI008Fixtures.payments;const v=k=>rr.filter(r=>r.kind===k).reduce((s,r)=>s+r.amount,0);const p=k=>pp.filter(x=>x.kind===k&&rr.some(r=>r.id===x.link)).reduce((s,x)=>s+x.amount,0);return {sales:v('sale'),cost:v('cost'),in:p('in'),out:p('out')}})();const financial=()=>''')
        s=s.replace("'32.400.000 <small>đ</small>'","uiSums.sales.toLocaleString('vi-VN')+' <small>đ</small>'").replace("metric('Chi phí đã xác nhận',12800000)","metric('Chi phí đã xác nhận',uiSums.cost)").replace("metric('Tiền đã thu liên quan kỳ',26400000)","metric('Tiền đã thu liên quan kỳ',uiSums.in)").replace("metric('Tiền đã chi liên quan kỳ',10800000)","metric('Tiền đã chi liên quan kỳ',uiSums.out)").replace("metric('Phải thu đã xác định',6000000)","metric('Phải thu đã xác định',uiSums.sales-uiSums.in)").replace("metric('Phải trả đã xác định',2000000)","metric('Phải trả đã xác định',uiSums.cost-uiSums.out)")
        # Original render replaces header: restore shell controls every time.
        bridge=bridge.replace('uChrome();U.ready',"const uRender=render;render=function(){uRender();uChrome()};uChrome();U.ready")
    if k in ['farm','finance','vault']:
        s=s.replace('<option>2025</option>','<option>2025</option><option>2024</option><option>2023</option>',1)
    # Standardize top-level rail/nav widths and spacing, while retaining rice task-specific rail.
    if k!='rice':
        extra='''@media(min-width:1101px){.shell{grid-template-columns:208px minmax(0,1fr)}.rail{padding:24px 14px}.rail .brand{font-size:18px;margin:0 0 26px}.nav button{min-height:48px;font-size:15px}.nav button[data-nav=quick]{margin:12px 0 4px}}@media(max-width:1000px){.bottom{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));min-height:64px;padding:5px 3px max(5px,env(safe-area-inset-bottom));background:#fff}.bottom button{width:auto;min-height:54px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:3px 0;font-size:10.5px;color:#53665a;white-space:nowrap}.bottom button[aria-current=page]{background:#e2ede1;color:#205b40;font-weight:700}.bottom button[data-nav=quick] svg{box-sizing:border-box;background:#205b40;color:white;width:30px;height:30px;padding:5px;border-radius:6px}}'''
    else:extra=''
    s=s.replace('</style>',css+extra+'</style>',1)
    s=s.replace('</script>',bridge+'\n</script>',1)
    docs[k]=s
# Embedded docs are local and trusted. No iframe src external URLs, no eval or new dependencies.
pack=json.dumps(docs,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
fixture=json.dumps(arrays,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
parent=r'''<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>Sổ Nông Dân · Field Ledger</title><style>
:root{font-family:Inter,'Noto Sans',system-ui,sans-serif;color:#1d3025;background:#f5f6ee}*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden}iframe{position:absolute;inset:0;border:0;width:100%;height:100%;background:#f5f6ee}iframe[hidden]{display:none!important}#loading{position:absolute;inset:0;display:grid;place-items:center;color:#53665a}#loading[hidden]{display:none}dialog{width:min(450px,calc(100% - 24px));max-height:90dvh;padding:0;border:1px solid #d2dbd1;border-radius:10px;background:#fff;color:#1d3025}dialog::backdrop{background:#1d30256b}.dh{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 18px;border-bottom:1px solid #d2dbd1}.dh h2{margin:0;font-size:19px}.dh button{min-width:44px;min-height:44px;border:1px solid #d2dbd1;border-radius:5px}.content{padding:12px 18px 18px}.content button{display:flex;align-items:center;justify-content:space-between;width:100%;padding:13px 10px;min-height:48px;border:0;border-bottom:1px solid #d2dbd1;text-align:left;font-weight:650}.content button.primary{background:#205b40;color:#fff;border-radius:5px;margin-bottom:6px}button{font:inherit;color:inherit;background:#fff;cursor:pointer}button:hover{background:#e2ede1}button:focus-visible{outline:3px solid #1267c5;outline-offset:2px}.content p{font-size:14px;line-height:1.5;margin:0 0 14px}button small{font-weight:400;color:inherit}.sr{position:absolute;width:1px;height:1px;clip:rect(0,0,0,0);overflow:hidden;white-space:nowrap}
</style></head><body><div id="loading" role="status">Sổ Nông Dân</div><main id="screens" aria-label="Sổ Nông Dân"></main><dialog id="global" aria-labelledby="global-title"><div class="dh"><h2 id="global-title"></h2><button type="button" id="global-close" aria-label="Đóng">×</button></div><div class="content" id="global-body"></div></dialog><script>
'use strict';const DOCS=__DOCS__;const fixtures=__FIXTURES__;function freeze(o){if(o&&typeof o==='object'){Object.values(o).forEach(freeze);Object.freeze(o)}return o}window.UI008Fixtures=freeze(fixtures);
const names={home:'Trang chủ',farm:'Sản xuất',finance:'Tài chính',vault:'Dữ liệu',rice:'Cân lúa',analytics:'Báo cáo'},entries={},instances=new Map(),trail=[];let active='home',activeEntry=null,scope='2026',serial=0,completed=0,instanceSeq=0,quickOpener=null,confirmRice=null;
const global=document.querySelector('#global'),body=document.querySelector('#global-body');function dialog(title,html){document.querySelector('#global-title').textContent=title;body.innerHTML=html;if(!global.open)global.showModal();document.querySelector('#global-close').focus()}
function ensure(route,transient=false){if(!transient&&entries[route])return entries[route];let frame=document.createElement('iframe');frame.id='screen-'+route+(transient?'-'+(++instanceSeq):'');frame.title=names[route];frame.hidden=true;let ready;const promise=new Promise(r=>ready=r),e={route,frame,promise,ready,api:null,transient};instances.set(frame.id,e);if(!transient)entries[route]=e;frame.srcdoc=DOCS[route];document.querySelector('#screens').append(frame);return e}
function removeTransient(e){if(e?.transient){instances.delete(e.frame.id);e.frame.remove()}}
function show(route,opts={},isBack=false,entry=null){let seq=++serial;const e=entry||ensure(route);active=route;activeEntry=e;for(const x of instances.values())x.frame.hidden=x!==e;document.title='Sổ Nông Dân · '+names[route];document.querySelector('#loading').hidden=true;e.promise.then(async api=>{if(seq!==serial)return;await api.activate(scope,opts,isBack,trail.length>0);if(seq===serial){completed=seq;if(!isBack)e.frame.contentWindow.focus()}})}
function navigate(route,opts={},deep=false,override=null){if(!names[route])return;if(route==='rice'&&scope!=='2026'&&override!=='2026'){confirmRice={route,opts,deep};dialog('Nhóm cân mẫu 2026',`<p>Năm đang xem: ${scope}. Prototype chỉ có nhóm cân năm 2026.</p><button class="primary" data-confirm-rice="1">Mở nhóm cân 2026 ›</button>`);return}if(route===active&&!Object.keys(opts).length&&!deep)return;const old=activeEntry;old?.api?.before();let e=null;if(deep&&route===active&&opts.action){show(route,opts,false,old);return}if(deep){trail.push({entry:old,scope});e=ensure(route,trail.some(t=>t.entry?.route===route));}else{trail.length=0;e=ensure(route)}if(override)scope=override;else if(fixtures.records.some(r=>r.id===opts.record||r.id===opts.related)||fixtures.payments.some(p=>p.id===opts.payment)||[...fixtures.records,...fixtures.payments].some(r=>'s-'+r.id===opts.source))scope='2026';show(route,opts,false,e);if(!deep)for(const x of [...instances.values()])if(x!==e)removeTransient(x)}
function back(){if(!trail.length){navigate('home');return}const old=activeEntry;old?.api?.before();const prev=trail.pop();scope=prev.scope;show(prev.entry.route,{},true,prev.entry);if(old!==prev.entry)removeTransient(old)}
const quicks=[['Cân lúa','rice',{}],['Bán tôm/cua','farm',{action:'sale'}],['Ghi chi phí','farm',{action:'cost'}],['Ghi thu','finance',{action:'receipt'}],['Ghi chi','finance',{action:'payment'}],['Chuyển tiền','finance',{action:'transfer'}],['Thêm chứng từ','vault',{tab:'docs',action:'add-source'}],['Nhập sổ cũ','vault',{tab:'imports',action:'start-import'}]];
function quick(){quickOpener=activeEntry?.frame.contentDocument.activeElement;dialog('Ghi nhanh',quicks.map(([n],i)=>`<button data-quick="${i}" class="${i===0?'primary':''}">${n}<span>›</span></button>`).join(''))}
window.UI008={navigate,back,quick,ready(route,api,win){const e=[...instances.values()].find(x=>x.frame.contentWindow===win&&x.route===route);if(!e)return;e.api=api;e.ready(api)},yearChanged(route,y,win){if(route===active&&activeEntry?.frame.contentWindow===win&&['2023','2024','2025','2026'].includes(y))scope=y},hasSource:id=>fixtures.records.some(x=>x.id===id)||fixtures.payments.some(x=>x.id===id),hasPayments:id=>fixtures.payments.some(x=>x.link===id),get current(){return active},get year(){return scope},get idle(){return serial===completed},get frameId(){return activeEntry?.frame.id}};
document.querySelector('#global-close').onclick=()=>global.close();global.addEventListener('close',()=>{confirmRice=null;if(quickOpener?.isConnected)quickOpener.focus({preventScroll:true});quickOpener=null});body.addEventListener('click',e=>{let b=e.target.closest('button');if(!b)return;if(b.dataset.confirmRice){const req=confirmRice;confirmRice=null;global.close();if(req)navigate(req.route,req.opts,req.deep,'2026');return}if(b.dataset.quick!==undefined){let q=quicks[Number(b.dataset.quick)];global.close();if(q)navigate(q[1],q[2],true)}});show('home');
</script></body></html>'''
parent=parent.replace('__DOCS__',pack).replace('__FIXTURES__',fixture)
(OUT/'So_Nong_Dan_UI008.html').write_text(parent,encoding='utf-8')
(OUT/'UI-008_Source_Inventory.json').write_text(json.dumps({k:{'source':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for k,p in paths.items()},ensure_ascii=False,indent=2)+'\n')
print('Built',len(parent.encode()),'bytes; checked identical shared records, payments, accounts and assets.')
