# SỔ NÔNG DÂN — Master Control Review Request

**Review ID đề xuất:** UI-001-MCR-01 · 27/11/2026

**Scope:** kiểm tra Field Ledger v0.2 đã được owner lựa chọn về định hướng; không kiểm tra/triển khai mã nguồn sản phẩm, không nghiệm thu checkpoint. Đọc `UI-001_Owner_Decision_Record.md` trước; tiếp đó mở ZIP v0.2 (audit, prototype, ảnh render, QA, manifest). ZIP v0.1 là nguồn lịch sử đối chiếu. Quyết định mới bổ sung trạng thái lịch sử, không thay đổi nội dung các gói đã xuất.

## 1. Cơ sở thẩm quyền

| Nguồn | Phiên bản / trạng thái |
|---|---|
| Master Specification, Decision Log, Architecture, Data Model, Calculation Contract, R1 contracts và invariants | GitHub `hnhuynh1003-blip/so-nong-dan` tại `3ae5e2be06e401adaca044aad6f9376e9b15e5c5` |
| Owner Acceptance Record | CP-001 ACCEPTED; CP-002 chỉ được phép đặc tả; D08–D12 OPEN |
| Design Audit | UI-001 v0.2, digest trong Owner Decision Record |
| Design Quality standard | DUDU Product Design v0.1.1 candidate, `31d4465c8ffa72769f8131b3fb6612c906676abc` |
| Quyết định mới | Owner chọn Field Ledger kết hợp theo nghiệp vụ; chưa nghiệm thu UI-001 |

Master Control cần xác minh nguồn tại các revision này. Live branch HEAD chưa được tái xác minh trong phiên ghi nhận quyết định. Không coi skill candidate là phê duyệt nghiệp vụ, stack hay quyền triển khai.

## 2. Hướng được chọn và biên giới roadmap

| UI | Mẫu bố cục tham chiếu | Phạm vi hiện tại |
|---|---|---|
| UI-002 Dashboard | 01 Bàn ghi sổ | Chưa đặc tả chi tiết, chưa bắt đầu |
| UI-003 Rice Weighing | Bàn thao tác chuyên dụng | Chưa bắt đầu; giữ D08/D10 OPEN |
| UI-004 Farm Management | 02 Sổ giao dịch, chi tiết ngữ cảnh | Chưa bắt đầu; D09/D12 OPEN |
| UI-005 Family Finance | 02 Sổ tài chính, đối chiếu | Chưa bắt đầu; không tự định khoản |
| UI-006 Data Vault | 02 Danh sách và vùng nguồn/chứng từ | Chưa bắt đầu; không OCR hay upload thật |
| UI-007 Analytics | 03 Tổng quan kỳ, báo cáo | Chưa bắt đầu; không kết luận thiếu căn cứ |

Mọi nhóm điều hướng cấp UX là lớp trình bày, không phải module/data model mới. Trang chủ ưu tiên ghi nhanh; Cân lúa là thao tác nổi bật trong fixture so sánh, không phải quy tắc mùa vụ tự động đã duyệt. Cấu trúc nhóm Trang chủ / Sản xuất / Ghi nhanh / Tài chính / Dữ liệu là proposal v0.2; Ghi nhanh chỉ là lối vào hành động. Hệ màu/token cụ thể, logo, typography và kích thước chi tiết cần được review như một reference ứng viên đã được owner chọn hướng, chưa phải đặc tả sản xuất bất biến.

## 3. Checklist bắt buộc — reviewer điền kết quả, không mặc định PASS

| ID | Câu hỏi review | Căn cứ / điều kiện đóng | Trạng thái |
|---|---|---|---|
| MC01 | Đúng phạm vi một gia đình, một người quản lý, mobile-first, tiếng Việt? | P01/D01/D04, không multi-tenant hoặc SaaS | PENDING |
| MC02 | Nhóm điều hướng có ánh xạ đầy đủ chức năng và không đổi route/module boundary? | `can-lua`, `ban-tom-cua`, `chi-phi`, `dat`, `quyet-toan`, `nhap-du-lieu`; báo cáo/data vault ở CP tương ứng; lối vào `Đất` phải tìm được | PENDING |
| MC03 | Có phân biệt doanh thu/chi phí ghi nhận và tiền đã thu/chi? | FIN-01/02, ADR 0003; cọc, thu nhiều lần, vay, chuyển nội bộ không cộng đôi; không kết luận lãi khi thiếu coverage | PENDING |
| MC04 | Số liệu kỳ sản xuất và dòng tiền có basis rõ? | Fixture liên quan kỳ sản xuất, không đồng nhất năm thanh toán; không dùng 2025 mô phỏng để suy luận dữ liệu thật | PENDING |
| MC05 | Provenance / verification / coverage và unknown/zero được phân biệt? | P06, INV-18/23; confirmed_zero phải có xác nhận; ước tính không post; nguồn có chứng từ không đảm bảo kỳ đầy đủ | PENDING |
| MC06 | Chi phí chung và phân bổ nhiều đất có giữ đúng phần chưa gán, tránh cộng trùng? | LAND-01/02; INV-07/08/09; không tự suy ra tenure/diện tích/chi phí cơ hội hoặc tỷ lệ phân bổ | PENDING |
| MC07 | D08/D10 và hợp đồng cân lúa được giữ nguyên? | RICE-01..06, INV-03..05/16/17; không tự chọn rounding, tie, scope, thứ tự ô, màu legacy; không finalize thiếu policy được duyệt | PENDING |
| MC08 | Thiết kế có ngôn ngữ offline/sync/backup trung thực? | P04/P07/P08, ADR 0002; lưu chỉ sau commit durable, sync ACK riêng, backup riêng; không silent overwrite; prototype không lưu | PENDING |
| MC09 | Nhập sổ cũ, source detail, import/export và quyền riêng tư đúng boundary? | DATA-01..03, OPS-01, INV-19/20/21/24; preview không post; không lấy attachment thật, không tự tạo quyền | PENDING |
| MC10 | Art direction và ba bố cục phù hợp task, không mất lối vào thiết yếu? | So ảnh cùng fixture/viewport; 01 task-first, 02 register, 03 report; kiểm tra điểm chính, mật độ, nhãn tiếng Việt | PENDING |
| MC11 | Có giữ đúng các gate kiểm thử và không phóng đại evidence? | Author score 69/85, không /100; WCAG/phone/production chưa thử; review độc lập tách riêng | PENDING |
| MC12 | Có xung đột giữa đề xuất token/component/navigation và baseline hay quyết định đã duyệt? | Nêu ngoại lệ, phân loại UX hoặc nghiệp vụ; không sửa kiến trúc/data model, không tự đóng D08–D12 | PENDING |

Reviewer nên ghi: ID, nguồn cụ thể, expected vs observed, severity (blocking/major/minor), affected task, hướng sửa, closure evidence và verdict. Đề xuất verdict: CONSISTENT / CONSISTENT WITH CONDITIONS / REVISION REQUIRED / BLOCKED. Các verdict là kết luận review, không phải owner acceptance hoặc quyền triển khai. Nếu nguồn không đọc được, ghi BLOCKED cho kiểm tra tương ứng; không suy đoán PASS.

## 4. Evidence hiện có và điểm mở

Bản v0.2 giữ nguyên, có 7 giao dịch giả lập, ba layout cùng fixture, ảnh mobile 390×844 và desktop 1440×900. QA lịch sử: Chromium 144.0.7559.96, nạp HTML bằng page.set_content, 5 viewport, 3 layout, không tràn ngang, mở intent cân, lọc/tìm/xem nguồn, xem thử bán, năm unknown, trạng thái mô phỏng, phản hồi khoảng kỳ không hợp lệ, Escape ở luồng mẫu; 5 cặp contrast chọn mẫu >=5.12:1. Không tái chạy browser trong lần ghi nhận này. Checksum được kiểm tra lại (15/15 v0.2; 7/7 v0.1).

| Rubric | v0.1 | 01 | 02 | 03 |
|---|---:|---:|---:|---:|
| Task & hierarchy /25 | 16 | 21 | 20 | 19 |
| Art direction /20 | 12 | 16 | 15 | 17 |
| Composition /20 | 11 | 16 | 18 | 17 |
| Continuity/semantics /20 | 12 | 16 | 16 | 16 |
| Accessibility/responsive/states /15 | NOT TESTED | NOT TESTED | NOT TESTED | NOT TESTED |
| Phần đã đánh giá /85 | 51 | 69 | 69 | 69 |

Chấm bởi tác giả Design Studio, không phải kiểm tra độc lập; fixture cũ và mới khác nhau, không phải benchmark kiểm soát giữa hai phiên bản skill. Không tổng /100 hoặc tuyên bố đạt >=80. Candidate skill chưa promotion.

| Open finding | Giới hạn | Closure đề xuất ở giai đoạn được phép |
|---|---|---|
| F01 | Nhãn phụ nhỏ; độ đọc dưới nắng chưa thử | Review trên điện thoại thật, zoom, nội dung tiếng Việt dài |
| F02 | Native date có thể theo định dạng Mỹ | Kiểm chứng hiển thị ngày vi-VN, không đổi hợp đồng ngày nghiệp vụ |
| F03 | Đóng form làm mất draft; focus khi re-render chưa kiểm đầy đủ | Thiết kế trạng thái unsaved và hành vi bảo toàn draft/focus; test khi có quyền triển khai |
| F04 | Hàng giao dịch dạng button, chưa semantic table/AT | Review screen reader, tab order, role/name, focus, zoom và tương phản toàn diện |
| F05 | `file://` chưa test; không có representative working product surface | Môi trường browser được phép; so actual UI với reference cùng fixture, viewport và theme |
| F06 | Chỉ mockup/fixture, không có nghiệp vụ/persistence/sync/auth thực | Các CP tương ứng, A01–A12; không dùng prototype thay cho acceptance |
| F07 | Independent critique, owner walkthrough và review kiến trúc chưa thực hiện | Master Control hoặc reviewer độc lập ghi findings; owner quyết định riêng |

Không dùng điểm cao để bỏ qua critical gate: mất thao tác, sai ngữ nghĩa, trạng thái giả, rò rỉ dữ liệu, mất dữ liệu, thiếu bằng chứng visual hoặc lỗi accessibility nghiêm trọng.

## 5. Visual fidelity plan — dùng khi có quyền implementation, không phải lệnh triển khai hiện tại

| Vùng tham chiếu | Thành phần dự kiến | Data/action contract cần đối chiếu | Responsive / evidence |
|---|---|---|---|
| Header + năm/kỳ | Context selector | Business date / production period distinct | Không cắt tên dài; snapshot cùng kỳ |
| 01 vùng ghi nhanh | Action region | Intent đến module hiện có, không giả handler | Mobile 48–64 px mục tiêu, desktop vùng làm việc; thao tác thật khi CP cho phép |
| 02 sổ giao dịch | Toolbar + register + source detail | Filter scope, source/revision, verification/payment/land allocation | Mobile list, desktop table/panel; keyboard + reader + continuity |
| 03 tổng quan kỳ | Metric spread | Confirmed/estimated, coverage, recorded vs settled, no inferred profit | Đọc số dài, đúng basis, drill-down và nguồn |
| Status vùng dữ liệu | Inline status | Local durable / pending sync / ACK / backup / conflict distinct | Chữ + biểu tượng, không màu đơn độc, real state test |

Tokens reference: `UI-001_Design_Audit.md` §4. Freeze chính xác region→component→token→data/action→responsive/evidence sau review và xác nhận ngoại lệ; các digest hiện tại định danh reference đã chọn hướng, không xác nhận fidelity của implementation chưa có. Chỉ khi được cấp quyền mới dựng một working surface thực tế, kiểm tra browser hợp lệ, reviewer độc lập và owner walkthrough trước khi mở rộng. Không replace handler thật bằng fixture.

## 6. Yêu cầu trả kết quả

1. Trả verdict và findings theo MC01–MC12, ghi rõ nguồn và giới hạn.
2. Chỉ ra các điểm cần Design Studio sửa và điểm cần owner quyết định; không tự đóng D08–D12.
3. Đề xuất có thể trình owner nghiệm thu UI-001 hay phải revision thêm; nếu chấp nhận có điều kiện, ghi residual risk và gate còn mở.
4. Đề xuất phạm vi UI-002 để owner xem xét, nhưng không bắt đầu UI-002, không CP-002 implementation, không sửa repo/CI/deploy/Codex.

**Trạng thái khi bàn giao:** OWNER SELECTED / MASTER CONTROL REVIEW PENDING / UI-001 ACCEPTANCE PENDING. Chưa gửi trực tiếp sang Master Control; owner chuyển gói này. Không có implementation SHA mới.
