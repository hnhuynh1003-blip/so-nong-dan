# SỔ NÔNG DÂN — UI-001 Owner Decision Record

- Ngày ghi nhận: 27/11/2026 (Asia/Ho_Chi_Minh).
- Đối tượng: UI-001 Design Audit v0.2 / Field Ledger.
- Thẩm quyền: Project Owner. Nguồn: chỉ thị trực tiếp trong cuộc trò chuyện Design Studio.
- Trạng thái: **DIRECTION OWNER SELECTED — MASTER CONTROL REVIEW PENDING — UI-001 ACCEPTANCE PENDING**.

## 1. Quyết định nguyên văn

> UI-001 Design Audit v0.2 — Owner Decision: Chọn Field Ledger, kết hợp bố cục theo nghiệp vụ.
> Nhận xét:
> Chuẩn bị hồ sơ review cho Master Control. Không triển khai mã nguồn hoặc tự nghiệm thu checkpoint.

Không có nhận xét bổ sung. Bản ghi này là bản chép quyết định, không phải chữ ký số, xác minh độc lập hoặc quyết định thay mặt chủ dự án.

## 2. Phạm vi được lựa chọn

Field Ledger / Sổ thực địa: một hệ nhận diện thống nhất, sử dụng các mẫu bố cục theo tác vụ, không phải ba chế độ giao diện độc lập:
- 01 Bàn ghi sổ: hướng bố cục trang chủ và điểm vào ghi nhanh.
- 02 Sổ giao dịch: hướng tham chiếu cho hồ sơ sản xuất, tài chính, công nợ, dữ liệu.
- 03 Tổng quan kỳ: hướng tham chiếu cho quyết toán và báo cáo.

Giữ Requirement-first, Reuse-first, Free-first; Work First, Ledger Rhythm, Quiet Premium, Honest Data, Field Ready. Giữ bảng màu rừng xanh, nền sáng trung tính, kiểu chữ sans hỗ trợ tiếng Việt, số căn theo hàng/cột, accent tiết chế, không dùng màu làm tín hiệu duy nhất. Đây là định hướng được chọn; các giá trị token, logo, thành phần, breakpoint, shortcut và chi tiết hành vi vẫn là đề xuất của v0.2 cần Master Control rà soát và owner xác nhận ngoại lệ nếu cần. Không suy diễn đã duyệt mọi pixel hoặc mọi quyết định thiết kế.

## 3. Cố định bản tham chiếu (reference pin, không phải visual acceptance)

Repository sản phẩm: `hnhuynh1003-blip/so-nong-dan`. Branch tham chiếu: `checkpoint/cp-001-r2`. Owner Acceptance Record HEAD: `3ae5e2be06e401adaca044aad6f9376e9b15e5c5`. Không xác nhận live branch HEAD mới trong tác vụ này.

Skill: `hnhuynh1003-blip/dudu-skills`, commit `31d4465c8ffa72769f8131b3fb6612c906676abc`, DUDU Product Design v0.1.1 candidate (review/pilot only).

- `UI-001_Design_Audit_v0.2.zip` SHA-256: `c38b184cb3686e29d40cbbdb3f038d628bf7f5a6970c7fdc154fc126fd2523c4`.
- `UI-001_Layout_Review.html` SHA-256: `bd8f8925cd3b45c7b88819a64957d27a3d620f283940f9f620b4a0e33d1c6046` (bên trong ZIP v0.2).
- `UI-001_Design_Audit.md` SHA-256: `454918f4d5e2ace3fdcc5c52f8f3414f0fbbdffd01ff4c9a375bde2ba1f26094` (bên trong ZIP v0.2).
- Bản v0.1 giữ nguyên để đối chiếu/rollback: `UI-001_Design_Review_Package.zip` SHA-256 `3acb181b30d1f00ffbca17bc50ae77b4fb8f9a443ae2110c85b83da5592b8e6a`.

Đối chiếu lại các manifest trong phiên ghi nhận: v0.2 15/15, v0.1 7/7; cả hai ZIP đọc được, CRC không lỗi, nội dung thành viên trùng byte với tệp hiện có. Không sửa các artifact cũ hoặc manifest cũ. Biên bản này bổ sung lịch sử quyết định, không ghi đè trạng thái lịch sử trong báo cáo audit.

## 4. Giới hạn và gate

- CP-001 ACCEPTED theo owner record hiện có; CP-002 SPECIFICATION AUTHORIZED / IMPLEMENTATION NOT AUTHORIZED; D08–D12 OPEN; A01–A12 NOT RUN theo phạm vi nghiệm thu sản phẩm đã ghi nhận. Không thay đổi checkpoint.
- UI-001 v0.2: owner chọn hướng; review độc lập, kiểm chứng accessibility đầy đủ và nghiệm thu vẫn pending. UI-002–007 NOT STARTED. Không tự mở UI-002.
- Không đổi nghiệp vụ, kiến trúc, route, data model, nguồn/công thức tài chính, dữ liệu thật. Không cài dependency, commit, merge, CI, deploy, Codex hoặc mua dịch vụ.
- Master Control kiểm tra tính nhất quán và đưa ra kết luận; owner quyết định nghiệm thu UI-001 và quyền mở giai đoạn tiếp theo. Không yêu cầu Master Control tự nghiệm thu thay owner.
- Không thực hiện chuyển giao trực tiếp sang cuộc trò chuyện khác. Hồ sơ sẵn sàng để owner chuyển vào Master Control.
