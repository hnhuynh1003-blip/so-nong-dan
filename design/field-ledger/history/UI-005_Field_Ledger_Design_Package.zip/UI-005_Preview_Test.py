from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
html=(p/'UI-005_Family_Finance.html').read_text()
log=[]
def make(b,w,h):
 page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1);page.set_default_timeout(3500);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(html,wait_until='load',timeout=7000);return page,errors
def check(page,errors):
 assert not errors,errors
 assert not page.evaluate('document.documentElement.scrollWidth>innerWidth'), 'overflow'
def shot(page,name):page.screenshot(path=str(p/name),timeout=5000)
def close(page):page.locator('[data-act=close]').click()
def tab(page,t):page.locator(f'[data-tab={t}]').click()
def fill(page,n,v):page.locator(f'#entry [name={n}]').fill(v)
def choose(page,n,v):page.locator(f'#entry [name={n}]').select_option(v)
def submit(page):page.locator('#entry button[type=submit]').click()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],timeout=6000)
 log.append('Chromium '+b.version+'; page.set_content; standalone HTML; no install or external service')
 for w,h in [(390,844),(320,700),(768,1024),(1280,720),(1440,900)]:
  page,errors=make(b,w,h);assert page.locator('#rows .row').count()==12
  for t in ['cashflow','debt','accounts','loans','assets']:
   tab(page,t);check(page,errors)
   if t=='cashflow':shot(page,f'Finance_{w}.png')
   elif w in (390,1440):shot(page,f'{t.capitalize()}_{w}.png')
  log.append(f'{w}x{h}: 5 tabs render/no horizontal document overflow PASS');page.close()
 page,errors=make(b,390,844)
 assert '34.400.000' in page.locator('.summary').inner_text() and '14.950.000' in page.locator('.summary').inner_text() and '19.450.000' in page.locator('.summary').inner_text()
 page.locator('#filter').select_option('transfer');assert page.locator('#rows .row').count()==1;assert '34.400.000' in page.locator('.summary').inner_text();page.locator('[data-item=p11]').click();assert 'không tăng tổng thu hoặc chi' in page.locator('#dbody').inner_text();close(page);log.append('Cash flow: exact synthetic totals, transfer excluded; filter leaves period summary intact PASS')
 tab(page,'debt');assert '6.000.000' in page.locator('.summary').inner_text() and '2.000.000' in page.locator('.summary').inner_text();assert page.locator('#rows .row').count()==5;page.locator('#filter').select_option('unknown');assert page.locator('#rows .row').count()==2;page.locator('[data-item=r5]').click();assert 'Không tự suy ra' in page.locator('#dbody').inner_text();close(page);page.locator('#filter').select_option('all');page.locator('[data-item=r6]').click();assert '10.000.000' in page.locator('#dbody').inner_text() and '5.000.000' in page.locator('#dbody').inner_text();shot(page,'Debt_detail_390.png');page.locator('#dbody [data-act=receipt]').click();fill(page,'day','27/11/2026');fill(page,'amount','1000000');choose(page,'account','bank');submit(page);assert '2.000.000' in page.locator('#result').inner_text();shot(page,'Receipt_390.png');fill(page,'amount','4000000');submit(page);assert 'Thanh toán vượt: 1.000.000' in page.locator('#result').inner_text();close(page);page.locator('[data-item=r6]').click();page.locator('#dbody [data-act=receipt]').click();assert page.locator('[name=amount]').input_value()=='4000000';close(page);assert '6.000.000' in page.locator('.summary').inner_text();log.append('Debt: 6m receivable / 2m payable; 2 unknowns excluded; two installments, partial/overpayment, in-session form draft, no mutation PASS')
 tab(page,'accounts');assert '25.450.000' in page.locator('.summary').inner_text();page.locator('[data-item=cash]').click();assert '8.850.000' in page.locator('#dbody').inner_text();page.locator('#dbody [data-act=reconcile]').click();fill(page,'day','27/11/2026');fill(page,'amount','8800000');submit(page);assert '−50.000' in page.locator('#result').inner_text();shot(page,'Reconcile_390.png');close(page);page.locator('#register [data-act=transfer]').click();fill(page,'day','27/11/2026');fill(page,'amount','1000000');choose(page,'to','cash');submit(page);assert 'hai tài khoản khác nhau' in page.locator('#result').inner_text();choose(page,'to','bank');submit(page);assert 'Không thay đổi tổng tiền' in page.locator('#result').inner_text();shot(page,'Transfer_390.png');close(page);log.append('Accounts: synthetic opening + movements, no actual balance claim, signed reconciliation and same-account rejection PASS')
 tab(page,'loans');assert '6.000.000' in page.locator('.summary').inner_text() and '200.000' in page.locator('.summary').inner_text();page.locator('#register [data-act=repay]').click();fill(page,'day','27/11/2026');fill(page,'principal','1000000');fill(page,'interest','100000');submit(page);assert '1.100.000' in page.locator('#result').inner_text();shot(page,'Repay_390.png');fill(page,'principal','7000000');submit(page);assert 'vượt dư gốc' in page.locator('#result').inner_text();close(page);log.append('Loan: principal vs interest, split payment preview, excess principal blocked PASS')
 tab(page,'assets');page.locator('[data-item=asset2]').click();assert 'Giá mua chưa biết' in page.locator('#dbody').inner_text();page.locator('#dbody [data-act=valuation]').click();fill(page,'day','27/11/2026');fill(page,'amount','0');submit(page);assert '0 đ' in page.locator('#result').inner_text();shot(page,'Valuation_390.png');close(page);log.append('Assets: unknown purchase, explicit zero observation, no depreciation or journal claim PASS')
 tab(page,'cashflow');page.locator('[data-item=p1]').click();page.locator('#dbody [data-act=source]').click();assert 'PT01' in page.locator('#dbody').inner_text();shot(page,'Source_390.png');page.locator('[data-act=back-detail]').click();assert 'Thu tiền bán tôm sú' in page.locator('#dbody').inner_text();close(page);page.locator('#register [data-act=receipt]').click();page.get_by_text('Tiền đặt cọc',exact=True).click();page.locator('#dbody [data-act=deposit]').click();fill(page,'day','27/11/2026');fill(page,'amount','2000000');submit(page);assert 'Không ghi doanh thu' in page.locator('#result').inner_text();close(page);page.locator('#register [data-act=receipt]').click();page.get_by_text('Tiền đặt cọc',exact=True).click();page.locator('#dbody [data-act=apply]').click();assert 'không tạo thêm tiền vào' in page.locator('#dbody').inner_text();close(page);log.append('Source provenance and deposit preview / empty allocation guard PASS')
 page.locator('[data-act=states]').click();page.locator('[data-state=error]').click();assert 'Không tải được sổ' in page.locator('#rows').inner_text();page.locator('[data-act=retry]').click();assert page.locator('#rows .row').count()==12;page.locator('#year').select_option('2025');assert page.locator('#rows .row').count()==0;assert '—' in page.locator('.summary').inner_text() and 'độ phủ chưa biết' in page.locator('.summary').inner_text();shot(page,'Unknown_390.png');check(page,errors);log.append('Mock error/retry, missing year != zero, no uncaught JS errors PASS');page.close();b.close()
(p/'UI-005_QA.txt').write_text('\n'.join(log)+'\n')
print('\n'.join(log))
