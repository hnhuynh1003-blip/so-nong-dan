from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
html=(p/'UI-003_Rice_Weighing.html').read_text()
clean=p.parent/'ui002-clean'
log=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],timeout=6000)
 print('Chromium',b.version,flush=True)
 for w,h in [(390,844),(320,700),(768,1024),(1280,720),(1440,900)]:
  page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1);page.set_default_timeout(3000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(html,wait_until='load',timeout=5000)
  assert page.locator('#grid .cell').count()==25
  assert not errors,errors
  measure=page.evaluate('''() => ({overflow:document.documentElement.scrollWidth>innerWidth,gridBottom:Math.round(document.querySelector('#grid').getBoundingClientRect().bottom),keypadBottom:Math.round(document.querySelector('#keypad').getBoundingClientRect().bottom),cellHeight:Math.round(document.querySelector('.cell').getBoundingClientRect().height),keyHeight:Math.round(document.querySelector('.key').getBoundingClientRect().height)})''')
  assert not measure['overflow'],measure
  page.screenshot(path=str(p/f'Rice_{w}.png'),timeout=5000);log.append(f'{w}x{h} default: {measure}; JS errors={errors}');print(log[-1],flush=True)
  if w==390:
   page.locator('[data-key="4"]').click();page.locator('[data-key="5"]').click();assert page.locator('#metrics').inner_text().startswith('Số bao · phiếu\n63');page.screenshot(path=str(p/'Entry_390.png'));page.locator('[data-key="2"]').click();assert page.locator('[data-cell="13"]').inner_text()=='64\n45,2';assert page.locator('#entryLabel').inner_text()=='Bao 65';assert '64' in page.locator('#metrics .metric').first.inner_text();page.locator('[data-act=undo]').click();assert '—' in page.locator('[data-cell="13"]').inner_text();assert '63' in page.locator('#metrics .metric').first.inner_text()
   page.keyboard.type('000');assert page.locator('#commit').is_disabled();assert '63' in page.locator('#metrics .metric').first.inner_text();page.locator('[data-key=clear]').click()
   page.locator('[data-cell="0"]').click();before=page.locator('[data-cell="0"]').inner_text();page.keyboard.type('452');assert page.locator('[data-cell="0"]').inner_text()==before;page.locator('#commit').click();assert '45,2' in page.locator('[data-cell="0"]').inner_text();page.locator('[data-act=undo]').click();assert page.locator('[data-cell="0"]').inner_text()==before
   page.locator('[data-cell="13"]').click();page.keyboard.type('44');page.locator('[data-board="0"]').click();assert 'Bảng 3' in page.locator('[data-board="2"]').inner_text();assert page.locator('[data-board="2"]').get_attribute('aria-current')=='true';assert '44' in page.locator('#entryValue').inner_text();page.keyboard.press('Escape')
   # fill remainder of board and check page/board creation, no overwrites
   for _ in range(12):page.keyboard.type('443')
   assert page.locator('#pageLabel').inner_text()=='Trang 2/2';assert page.locator('#entryLabel').inner_text()=='Bao 76';assert '75' in page.locator('#metrics .metric').first.inner_text();assert page.locator('#grid .cell').count()==25
   page.locator('[data-act=undo]').click();assert page.locator('#pageLabel').inner_text()=='Trang 1/1';assert '74' in page.locator('#metrics .metric').first.inner_text();page.keyboard.type('443')
   page.locator('.actions [data-act=deduct]').click();page.locator('#tareType').select_option('ratio');page.locator('#tg').fill('1');page.locator('#tb').fill('0');page.locator('#dedform button[type=submit]').click();assert 'lớn hơn 0' in page.locator('#formError').inner_text();page.locator('#tb').fill('10');page.locator('#imp').fill('0');page.locator('#price').fill('7350');page.screenshot(path=str(p/'Deductions_390.png'));page.locator('#dedform button[type=submit]').click();assert not page.locator('#modal').is_visible()
   page.locator('.actions [data-act=review]').click();assert page.get_by_role('button',name='Chốt phiếu',exact=True).is_disabled();assert 'D08' in page.locator('#dbody').inner_text();page.screenshot(path=str(p/'Review_390.png'));page.keyboard.press('Escape')
   page.locator('.top [data-act=group]').click();assert '7.350 đ/kg' in page.locator('#dbody').inner_text() and '7.200 đ/kg' in page.locator('#dbody').inner_text();page.screenshot(path=str(p/'Group_390.png'));page.locator('[data-open-sheet="1"]').click();assert '—' in page.locator('#financial').inner_text();page.locator('.top [data-act=group]').click();page.locator('#dbody [data-act=new-sheet]').click();assert 'Phiếu 03' in page.locator('#sheetSelect option:checked').inner_text();assert page.locator('#grid .empty').count()==25;assert '—' in page.locator('#financial').inner_text();page.evaluate('scrollTo(0,0)');page.screenshot(path=str(p/'Empty_390.png'));assert not errors,errors
   log.append('390x844 interactions: partial buffer excluded, 000 rejected, auto-commit empty, explicit edit, undo, draft switch guard, 75->76 next page no overwrite, ratio denominator rejected, draft preview no finalize, group multi-price, new sheet empty PASS.')
  page.close()
 for w,h in [(390,844),(1440,900)]:
  page=b.new_page(viewport={'width':w,'height':h});page.set_default_timeout(3000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content((clean/'UI-002_Dashboard_v0.2.html').read_text());assert page.locator('h1').inner_text()=='Trang chủ';assert 'Ghi nhận và xem lại công việc.' not in page.locator('body').inner_text();assert not page.evaluate('document.documentElement.scrollWidth > innerWidth');assert not errors;page.screenshot(path=str(clean/f'Dashboard_{w}.png'));log.append(f'UI-002 v0.2 {w}x{h}: title/copy cleanup + no overflow or JS errors PASS');page.close()
 b.close()
(p/'UI-003_QA.txt').write_text('Chromium 144 system executable; page.set_content, no file URL, no production code.\n'+'\n'.join(log)+'\nNot tested: real phone, full WCAG, screen reader, real data, persistence, business engine, sync.\n')
print('\n'.join(log),flush=True)
