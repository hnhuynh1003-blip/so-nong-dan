# SỔ NÔNG DÂN — UI-003 v0.2 · Cân lúa / Field Ledger

**Trạng thái: PROPOSED — chờ chủ dự án duyệt UI-003.** Đây là bản prototype thiết kế độc lập, không phải mã nguồn sản phẩm. UI-002 đã được chủ dự án duyệt thiết kế và yêu cầu rút gọn câu chữ; bản chỉnh copy v0.2 nằm trong `ui002-clean/`. Không tự nghiệm thu CP hoặc thay đổi D08–D12.

## 1. Căn cứ và quyền hạn

- Master Specification, Calculation Contract, R1 Domain Contracts, Invariant Register và Owner Acceptance Record tại `hnhuynh1003-blip/so-nong-dan`, HEAD tham chiếu `3ae5e2be06e401adaca044aad6f9376e9b15e5c5` (đã đọc trong các bước trước, không tuyên bố branch HEAD hiện tại đã được xác minh lại).
- Field Ledger: Owner Selected từ UI-001 Design Audit v0.2; giữ nhận diện xanh rừng, nền sáng, chữ số tabular, đường phân cách và vùng làm việc ưu tiên tác vụ. Không coi lựa chọn hướng là nghiệm thu toàn bộ UI-001.
- DUDU Product Design v0.1.1 candidate, commit `31d4465c8ffa72769f8131b3fb6612c906676abc`, creative-direction / design-standard / review-gates. Không nâng cấp chính thức skill.
- CP-001 ACCEPTED; CP-002 SPECIFICATION AUTHORIZED, IMPLEMENTATION NOT AUTHORIZED; D08–D12 OPEN.
- Dữ liệu tổng hợp giả lập, không dữ liệu tài chính thật. Không dependency mới, không kết nối mạng, không repository mutation, không Codex, không backend hoặc deployment.

## 2. Tác vụ và bố cục

Người quản lý duy nhất cần ghi nhanh trọng lượng bao ở điểm cân, kiểm tra tổng theo cấp, sửa khi có sai sót, xem bì và giá tiền. Bố cục mobile dùng một cột: header ngắn / phiếu / tổng / trang và bảng / ma trận / vùng nhập / bàn phím / chi tiết. Desktop dùng sidebar phiếu, ma trận trung tâm, vùng nhập và tạm tính bên phải. Giữ nội dung chính, tránh tiêu đề diễn giải, icon trang trí, thẻ lặp. Bàn phím không fixed overlay để không che ma trận; ở màn 390x844 thấy đủ toàn bộ ma trận và phím; ở 320x700 cần cuộn dọc.

Cấu trúc nhóm > phiếu > trang (tối đa 3 bảng hiển thị qua tab) > bảng (25 ô) > bao. Trang là nhóm hiển thị của bảng, không tự tạo thêm thực thể nghiệp vụ. Xem bảng đang chọn, tổng cột, bảng, phiếu; modal Trang cho tổng trang, modal Nhóm cho tổng nhóm và giá riêng mỗi phiếu. Bảng cuối chưa đầy vẫn hợp lệ ở mức nháp. `＋ Bảng` và `＋ Thêm phiếu` chỉ tạo mẫu trong bộ nhớ phiên. Không tuyên bố tồn tại CRUD thực.

Dữ liệu ban đầu: Phiếu 01 gồm 3 bảng, 63 bao, tổng gộp 2.803,1 kg; Phiếu 02 gồm 10 bao, tổng gộp 445,4 kg; giá 7.350 và 7.200 đ/kg là ví dụ giả lập, không phải giá hiện hành. Phiếu 01 có giả định bì 1 kg / 10 bao và tạp chất đã đặt 0 trong fixture. Phiếu 02 chưa biết bì và tạp chất; không giả định 0. Không sử dụng dữ liệu app cũ năm 2025.

## 3. Tương tác nhập cân

- Chọn ô trực tiếp. Hiển thị kg trong lưới; buffer giữ chuỗi ba chữ số và diễn giải `443 = 44,3 kg`. Ô trống là dấu gạch, không phải 0; số đang gõ chưa hợp lệ không vào tổng.
- Thiết lập thử: mặc định theo hàng và tự ghi sau 3 chữ số cho ô trống; có thể đổi theo cột hoặc ghi thủ công. Đây là lựa chọn UX để thử nghiệm, **không** xác nhận thứ tự nhập của Cân Lúa v5. Màu xanh viền/đánh dấu ô chọn không phải mã màu nghiệp vụ cũ. D10 OPEN.
- Nếu chọn ô có số, nhập ba chữ số mới và bấm Ghi sửa; không tự ghi đè. Xóa ô yêu cầu xác nhận. Backspace / Xóa số tác động buffer, không xóa số đã ghi. Hoàn tác một lần thao tác hoặc nhiều bước trong bộ nhớ (giới hạn prototype 100 snapshot; không phải giới hạn sản phẩm). Đổi bảng/phiếu bị chặn nếu buffer chưa xử lý. Khi đầy tìm ô trống; nếu không còn, tạo bảng tiếp theo; trang chuyển khi vượt 3 bảng. Không ghi đè ô đầu.
- Trạng thái “Đã ghi ... trong phiên” là mô phỏng in-memory, không đồng nghĩa đã lưu bền vững. Tải lại mất chỉnh sửa. Không có auth, offline durable transaction, sync, backup, revision phiếu đã chốt hoặc thanh toán thật. Các trạng thái save/retry/conflict/permission của ứng dụng thật thuộc review triển khai sau.

## 4. Khấu trừ và tiền

Một phương thức bì ở cấp phiếu trong prototype: chưa xác định, không trừ, cố định, số bao/kg bì, kg bì/bao. Tạp chất độc lập, null khác 0. Số bao >0 cho tỷ lệ, bì/tạp chất không vượt gross, giá dương khi nhập, không trừ bì nhiều lần ở các cấp. Một phiếu có giá riêng, không lấy bình quân cộng đơn giá giữa phiếu. Chi tiết phiếu tách gross, bì, net vật lý, tạp chất, thương phẩm trước làm tròn, giá trị trước làm tròn, khối lượng tính tiền và tiền chốt. Phép tính demo dùng gram và VND nguyên BigInt, giữ phân số chính xác khi không chia hết, không giả định làm tròn. D08 OPEN: tiền chốt và khối lượng tính tiền hiện —, nút Chốt phiếu disabled. Không có revenue recognition hoặc financial posting. Giá trị trước làm tròn chỉ minh họa, không phải tiền phải trả. Phạm vi chưa mô phỏng: bì theo lượt/batch, phân bổ nhiều dòng giá trong cùng phiếu, điều chỉnh giảm tiền, chia sẻ/xuất phiếu, vòng đời phiếu chốt/hủy và revision; cần thiết kế tiếp nếu owner yêu cầu, không được xem là đã đáp ứng toàn bộ RICE-01..06.

## 5. Design tokens và copy

Dùng lại màu #205B40 / #174B35 / #E2EDE1 / #F5F6EE / #1D3025 / #53665A / #8A4D11 / #A72D29. Inter / Noto Sans / system fallback, không tải font ngoài. Bo góc 4–7 px cho lưới và nút, vùng chạm mobile 44 px (mục tiêu thực địa 48 px cần thử trên thiết bị thật), số chính 19–24 px, số nhập 25–31 px. Hạn chế badge và shadow, tránh emoji trang trí. Focus có viền, ô chọn có aria-pressed và chữ/viền; dialog native. Giữ nhãn demo, nháp, D08/D10 và trạng thái thiếu. UI-002 v0.2 đổi tiêu đề thành Trang chủ, bỏ subtitle và các mô tả nhỏ thừa ở nút, bỏ tagline lặp, đổi “Cần xem lại” thành “Cần rà soát”. Giữ cảnh báo chất lượng dữ liệu, thông tin kỳ và trạng thái giả lập. Bản v0.1 lịch sử không sửa.

## 6. Design critique (author review, không phải independent verification)

| Tiêu chí | Điểm tự đánh giá | Căn cứ / hạn chế |
|---|---:|---|
| Tác vụ và phân cấp | 22/25 | Ma trận và nhập là tâm điểm; tổng gộp thấy ngay, khấu trừ dưới vùng nhập. 320px phải cuộn. |
| Art direction | 16/20 | Nhận diện Field Ledger nhất quán, tiết chế màu và component; chưa walkthrough owner. |
| Bố cục/mật độ/typography | 17/20 | 5x5 + keypad ở 390x844; nhãn cột vẫn nhỏ, vùng chạm chỉ 44 px. |
| Liên tục/ngữ nghĩa | 17/20 | Buffer, undo, no-overwrite, D08 blocked, null/0; chưa cover đầy đủ nghiệp vụ và trạng thái hệ thống thật. |
| Accessibility/responsive/realistic states | NOT TESTED /15 | Có kiểm tra cơ bản viewport và điều khiển; chưa đủ WCAG, thiết bị thật, screen reader và trạng thái persistence. |

Tổng phần đã tự đánh giá: 72/85. Không quy đổi /100 hoặc tuyên bố đạt ngưỡng 80/100. Không độc lập, không benchmark v0.1.0/v0.1.1.

## 7. Bằng chứng và gate

`UI-003_QA.txt`, `UI-003_Preview_Test.py`, ảnh Chromium và manifest. Môi trường Playwright browser bundle thiếu, lệnh CLI file URL bị timeout trước đó; dùng Chromium hệ thống sẵn có bằng `page.set_content`, không cài gì thêm. PASS chỉ trong phạm vi prototype/viewport và tương tác được kiểm tra. Không chứng minh engine, A01–A12, tốc độ người dùng, quyền hạn, persistence, sync hoặc nghiệm thu. Ảnh 390 và 1440 được kiểm tra bằng mắt. UI-002 v0.2 chỉ kiểm tra lại copy/render 390/1440, không chạy lại toàn bộ nghiệp vụ mẫu UI-002. Master Control cần xem D08/D10, các chức năng còn thiếu, mapping UI/domain và kế hoạch triển khai khi được phép. Chủ dự án duyệt UI-003 hoặc yêu cầu biến thể tiếp theo; không tự mở UI-004.
