from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
log=[]
html=(p/'UI-004_Farm_Management.html').read_text()
def make(b,w,h,source):
 page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1);page.set_default_timeout(3000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(source,wait_until='load',timeout=7000);return page,errors
def check(page,errors):
 assert not errors,errors
 assert not page.evaluate('document.documentElement.scrollWidth>innerWidth')
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],timeout=6000)
 log.append('Chromium '+b.version+'; page.set_content; standalone HTML')
 for w,h in [(390,844),(320,700),(768,1024),(1280,720),(1440,900)]:
  page,errors=make(b,w,h,html);assert page.locator('#rows .row').count()==7;check(page,errors);page.screenshot(path=str(p/f'Farm_{w}.png'));log.append(f'{w}x{h} register render/no horizontal overflow PASS')
  if w in (390,1440):
   page.locator('[data-tab=land]').click();assert page.locator('[data-land]').count()==2;page.locator('[data-land=l2]').click();check(page,errors);page.screenshot(path=str(p/f'Land_{w}.png'))
   if w==390:page.keyboard.press('Escape')
   page.locator('[data-tab=cost]').click();assert page.locator('#rows .row').count()==3;check(page,errors);page.screenshot(path=str(p/f'Cost_{w}.png'))
   if w==390:
    page.locator('#activity').select_option('Chung');assert page.locator('#rows .row').count()==2;page.locator('[data-record=r4]').click();page.locator('#dbody [data-act=allocation]').click();page.locator('[name=land0]').fill('6000000');page.locator('#allocationForm button[type=submit]').click();assert 'vượt' in page.locator('#allocResult').inner_text();page.locator('[name=land0]').fill('2000000');page.locator('#allocationForm button[type=submit]').click();assert '3.000.000' in page.locator('#allocResult').inner_text();page.screenshot(path=str(p/'Allocation_390.png'));page.keyboard.press('Escape');assert page.locator('#rows .row').count()==2
    page.locator('[data-tab=records]').click();page.locator('#activity').select_option('Tôm');assert page.locator('#rows .row').count()==2;page.locator('#quality').select_option('Ước tính');assert page.locator('#rows .row').count()==1;page.locator('[data-record=r5]').click();assert 'Chưa biết' in page.locator('#dbody').inner_text();page.locator('#dbody [data-act=source]').click();assert 'trang 10' in page.locator('#dbody').inner_text();page.keyboard.press('Escape')
    page.locator('#register [data-act=sale]').click();page.locator('[name=day]').fill('27/11/2026');page.locator('[name=amount]').fill('2400000');page.locator('[name=activity]').select_option('Tôm và cua');page.screenshot(path=str(p/'Sale_390.png'));page.locator('#form button[type=submit]').click();assert 'Không tạo giao dịch' in page.locator('#result').inner_text();page.locator('details summary').click();page.locator('[data-act=add-line]').click();page.locator('[name=species0]').select_option('Tôm');page.locator('[name=lineamount0]').fill('3000000');page.locator('#form button[type=submit]').click();assert 'vượt' in page.locator('#result').inner_text();page.locator('[name=lineamount0]').fill('1500000');page.locator('[data-act=add-line]').click();page.locator('[name=species1]').select_option('Cua');page.locator('#form button[type=submit]').click();assert '900.000' in page.locator('#result').inner_text();page.keyboard.press('Escape');page.locator('#register [data-act=sale]').click();assert page.locator('[name=amount]').input_value()=='2400000';assert page.locator('[name=lineamount0]').input_value()=='1500000';page.keyboard.press('Escape')
    page.locator('#year').select_option('2025');assert page.locator('#rows .row').count()==0;assert '—' in page.locator('.summary').inner_text();page.screenshot(path=str(p/'Unknown_390.png'));page.locator('#year').select_option('2026');page.locator('footer [data-act=states]').click();page.locator('[data-state=error]').click();assert 'Không tải' in page.locator('#rows').inner_text();page.locator('[data-act=retry]').click();assert page.locator('#rows .row').count()==7;check(page,errors);log.append('Mobile: land/lease, shared-cost filter, allocation over-total and residual, source, mixed-sale lines and incomplete amounts, draft reopen, unknown year, retry PASS')
  page.close()
 rev=p/'revisions';rice=(rev/'UI-003_Rice_Weighing_v0.3.html').read_text();home=(rev/'UI-002_Dashboard_v0.3.html').read_text()
 for w,h in [(390,844),(1440,900)]:
  page,errors=make(b,w,h,rice);assert page.locator('[data-cell="17"] .idx').inner_text()=='64';assert page.locator('[data-cell="17"]').get_attribute('aria-pressed')=='true';assert page.locator('[data-cell="0"] .idx').inner_text()=='51';assert page.locator('[data-cell="5"] .idx').inner_text()=='52';check(page,errors);page.screenshot(path=str(rev/f'Rice_Column_{w}.png'))
  if w==390:
   
   for _ in range(12):page.keyboard.type('443')
   assert page.locator('#pageLabel').inner_text()=='Trang 2/2';assert page.locator('#entryLabel').inner_text()=='Bao 76';assert '75' in page.locator('#metrics .metric').first.inner_text();
   for j in range(5):
    assert page.locator('#entryLabel').inner_text()==f'Bao {76+j}';assert page.locator(f'[data-cell="{j*5}"]').get_attribute('aria-pressed')=='true';page.keyboard.type('443')
   assert page.locator('#entryLabel').inner_text()=='Bao 81';assert page.locator('[data-cell="1"]').get_attribute('aria-pressed')=='true';assert page.locator('[data-cell="20"] .value').inner_text()=='44,3';assert page.locator('[data-cell="1"] .value').inner_text()=='—';page.screenshot(path=str(rev/'Column_Five_Bags_390.png'));page.locator('[data-act=undo]').click();assert page.locator('#entryLabel').inner_text()=='Bao 80';check(page,errors);log.append('Rice v0.3: column numbering, five consecutive bags down column, next-column advance, 75->76 next page, undo PASS')
  page.close();page,errors=make(b,w,h,home);assert page.locator('h1').inner_text()=='Sổ Nông Dân';check(page,errors);page.screenshot(path=str(rev/f'Dashboard_{w}.png'));log.append(f'Dashboard v0.3 {w}x{h}: title and render PASS');page.close()
 b.close()
(p/'UI-004_QA.txt').write_text('\n'.join(log)+'\nNOT TESTED: physical devices, full WCAG/screen reader, real persistence, financial/land engine, actual authorization, full regression of UI-002/003.\n')
print('\n'.join(log))
