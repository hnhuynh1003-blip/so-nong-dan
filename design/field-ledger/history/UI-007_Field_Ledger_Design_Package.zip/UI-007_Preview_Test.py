from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
html=(p/'UI-007_Analytics.html').read_text()
log=[]
def make(b,w,h):
 page=b.new_page(viewport={'width':w,'height':h},device_scale_factor=1);page.set_default_timeout(3500);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(html,wait_until='load',timeout=7000);return page,errors
def check(page,errors):
 assert not errors,errors
 assert not page.evaluate('document.documentElement.scrollWidth>innerWidth'), 'horizontal overflow'
def shot(page,name,full=False):page.screenshot(path=str(p/name),timeout=7000,animations='disabled',full_page=full)
def tab(page,t):page.locator(f'[data-tab={t}]').click()
def year(page,y):page.locator('#year').select_option(str(y))
def drill(page,k):page.locator(f'[data-drill="{k}"]:visible').first.click()
def close(page):page.locator('#dialog [data-act=close]').click()
def txt(page,s='#bodygrid'):return page.locator(s).inner_text()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],timeout=6000)
 log.append('Chromium '+b.version+'; page.set_content; standalone HTML; no installation; not file URL runtime.')
 for w,h in [(390,844),(320,700),(768,1024),(1280,720),(1440,900)]:
  page,errors=make(b,w,h)
  for t in ['overview','production','land','cash','assets']:
   tab(page,t);check(page,errors)
   if t=='overview':shot(page,f'Analytics_{w}.png')
   elif w in (390,1440):
    if t=='land':year(page,2024)
    shot(page,f'{t.capitalize()}_{w}.png')
    if t=='land':year(page,2026)
  log.append(f'{w}x{h}: five report tabs; no horizontal document overflow or uncaught page errors PASS');page.close()
 page,errors=make(b,390,844)
 assert '32.400.000 đ' in txt(page) and '12.800.000 đ' in txt(page) and 'Chưa đủ dữ liệu' in txt(page)
 assert '26.400.000 đ' in txt(page) and '10.800.000 đ' in txt(page)
 assert page.locator('.yearbar[data-year="2025"] .missing').count()==1
 shot(page,'Analytics_390_full.png',True)
 page.locator('.yearbar[data-year="2024"]').click();assert page.locator('#year').input_value()=='2024' and '39.000.000 đ' in txt(page) and '18.300.000 đ' in txt(page)
 year(page,2025);assert page.locator('.lead strong').inner_text()=='—' and 'Độ phủ chưa biết' in txt(page);shot(page,'Unknown_390.png')
 year(page,2026);drill(page,'sale');assert page.locator('#dbody .source-row').count()==3;shot(page,'Drilldown_390.png');page.locator('[data-source=r6]').click();assert 'Phiếu bán mẫu 015' in txt(page,'#dbody') and page.locator('#dbody .source-row').count()==2;shot(page,'Source_390.png');page.locator('[data-act=back]').click();assert page.locator('#dbody .source-row').count()==3;close(page);assert page.locator('.lead').evaluate('(el)=>el===document.activeElement');log.append('Overview: source-consistent 2026 production totals, historical 2024 totals, gap 2025, chart selection, source and linked payments, back/focus PASS')
 tab(page,'production');assert '5.000.000 đ' in txt(page);assert page.locator('[data-drill="act:Tôm:cost"]').inner_text().strip().endswith('— ›');drill(page,'common');assert page.locator('#dbody .source-row').count()==1;close(page);log.append('Production: missing direct costs not zero; confirmed shared costs only, no whole-year profit PASS')
 tab(page,'land');assert '32.400.000 đ' in txt(page);assert page.locator('[data-drill="land:owned:sale"]').inner_text().strip().endswith('— ›');page.locator('[data-act=land-example]').click();assert page.locator('#year').input_value()=='2024';assert '18.000.000 đ' in txt(page) and '21.000.000 đ' in txt(page) and '6.000.000 đ' in txt(page);assert page.locator('.barrow[data-drill="land:unassigned:sale"]').inner_text().strip().endswith('0 đ ›');drill(page,'land:unassigned:sale');assert page.locator('#dbody .source-row').count()==6 and 'Phần dư' in txt(page,'#dtitle');close(page);log.append('Land: 2026 unassigned; 2024 assigned sums 39m with known 0 residual only for confirmed sale sample; 6m common unassigned; no efficiency ranking PASS')
 year(page,2026);tab(page,'cash');assert all(x in txt(page) for x in ['34.400.000 đ','14.950.000 đ','+19.450.000 đ','25.450.000 đ','1.000.000 đ']);drill(page,'cash-net');assert page.locator('#dbody .source-row').count()==11;close(page);drill(page,'transfer');assert page.locator('#dbody .source-row').count()==1;page.locator('[data-source=p11]').click();assert 'Chuyển nội bộ' in txt(page,'#dbody');close(page);drill(page,'balances');assert '8.850.000 đ' in txt(page,'#dbody') and '16.600.000 đ' in txt(page,'#dbody');close(page);log.append('Cash: 12 samples incl. transfer; excluded transfer in net, opening plus net matches account balances, actual balance unknown PASS')
 tab(page,'assets');assert page.locator('.lead strong').inner_text()=='—' and '6.000.000 đ' in txt(page) and '2.000.000 đ' in txt(page);drill(page,'receivable');assert page.locator('#dbody .source-row').count()==2 and txt(page,'#dbody').count('3.000.000 đ')==2;close(page);drill(page,'valuation-year:2024');assert '2024 · Dữ liệu giả lập' in txt(page,'#dbody') and '22.000.000 đ' in txt(page,'#dbody');close(page);drill(page,'net-worth');assert 'Cần giá trị tài sản và nợ tại cùng ngày' in txt(page,'#dbody');shot(page,'Net_Worth_390.png');close(page);log.append('Assets: net worth unavailable, known receivables derived from original payment samples, dated valuation source correct, no implied growth PASS')
 page.locator('[data-act=states]').click();page.locator('[data-state=error]').click();assert 'Không tải được' in txt(page);page.locator('[data-act=retry]').click();assert 'Tài sản ròng' in txt(page);page.locator('[data-act=states]').click();page.locator('[data-state=permission]').click();assert 'Không có quyền' in txt(page) and page.locator('.lead').count()==0;tab(page,'overview');check(page,errors);log.append('Mock error/retry and permission states hide metrics; tab restores sample; no uncaught JS errors PASS');page.close();b.close()
(p/'UI-007_QA.txt').write_text('\n'.join(log)+'\n',encoding='utf-8');print('\n'.join(log))
