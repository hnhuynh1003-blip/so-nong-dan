import * as A from './build/index.js';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
let pass=0,errors=0;
for(const [i,l] of readFileSync('verifier-extra.jsonl','utf8').trimEnd().split('\n').entries()){
 const v=JSON.parse(l); if(v.error){assert.throws(()=>A[v.op](...v.args),e=>e instanceof A.ArithmeticError&&e.code===v.error,`row ${i+1}`);errors++}else{assert.deepEqual(A[v.op](...v.args),v.value,`row ${i+1}`);pass++}
}console.log(JSON.stringify({pass,errors,total:pass+errors}));
