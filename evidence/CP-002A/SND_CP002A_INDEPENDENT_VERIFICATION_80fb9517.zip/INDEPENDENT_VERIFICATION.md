# SND CP-002A - Independent verification record

Disposition: VERIFIED (isolated A-P1 arithmetic scope only); owner acceptance pending. No repository write or further implementation. CP-001 ACCEPTED; B-F NOT AUTHORIZED. D06 and D08.1-6 confirmed; D09-D12 open.

## Remote readback via GitHub connector
- Repository hnhuynh1003-blip/so-nong-dan; branch checkpoint/cp-002a; candidate 80fb95175e902e6bea3caac518a8a6b25b9c1815; tree 1bcb9ca31eebed744b3448c4c6387d9c50935405; sole parent 3ae5e2be06e401adaca044aad6f9376e9b15e5c5. Ahead 1, behind 0.
- 175 candidate blobs vs 162 parent; 159 identical blob/mode; 16 added/modified, 0 removed. Accepted source, SQL, lockfiles, workflows and historical evidence unchanged. PR #1 draft/unmerged at accepted baseline; only three historical CI runs.
- Candidate manifest: 174 unique paths, no missing/extra paths. SHA-256 independently computed from fetched bytes for all 15 new/modified paths other than manifest and for the old CP-001-R2 manifest (16 matches). All other unchanged paths have matching inherited checksums. This is continuity verification, not a new full-tree byte rehash.
- Attached draft and R1 source hashes matched local files and remote manifest: d9d48d2d42ac7e84e200acb43b4800eb3b990ff969495b150f1b6ed02d1b0856 and 00d9f26656f37af68dafeceac684ae97a13ffb89e91f945d3131e94911dee2ec.
- Engineering evidence ZIP 7715 bytes, SHA-256 8361aca880d7d1998a5e6a66951cf11f6d8856386273addbef3d9c3b003ac2cc. Independently decoded/decompressed via connector; 16/16 entries CRC and lengths matched; 15/15 internal hashes and coverage matched. Environment records source hashes and compiler files matching local copies; benchmark result digests match all three groups. Original Engineering logs remain in repository; this is a verifier summary, not their duplicate raw logs.
- E15, authorization, README and status agree; original historical decision rows preserved with current override. All 64 registered IDs retained: 13 PASS A-P1 portions, 51 wholly NOT RUN, deferred portions NOT RUN.

## Independent local replay
Git DNS prevented full checkout. Exact source, oracle, Node tests and benchmark were reconstructed from connector content, then independently byte-hashed against the candidate manifest. `index.ts` also matched Git blob c5d4c206d39e2190f44b58c9c4c67f7596e232b0. No edits to candidate files in this local package. Local TypeScript 5.8.3, Node 22.16.0, npm 10.9.2, Python 3.13.5; compiler entry and implementation hashes match Engineering archive, but clean lock-resolved installation was not performed. Isolated compile uses identical relevant baseline flags; compiled output SHA-256 0ae72562d05abffd1dddf326e015f88f9e1822ddbe0ce1de818e271cef3f7338 matches Engineering. Oracle generated twice, byte-identical digest 6501578c96186b5ab2e20e7cbddb5d6dfcb70305ec9f75419c8a6ffe5b3e09eb. Independent comparison runner and exact committed test file both executed: 10779/10779 match, 10289 exact results, 490 expected errors; 7/7 Node groups pass; 5783 rounding properties, 959 conservation checks, 240 monotonicity pairs. Additional verifier-generated seed 20261128: 1356/1356 match, 1288 exact and 68 expected errors; random quantum up to 256 digits and large Fibonacci pairs. Benchmark 100000 ops succeeds; 100001 guard exits 1 as expected. Benchmark is synthetic fixed-input microbenchmark, not production SLA. Raw replay logs in this archive; generated JSONL omitted because reproducible from included generators.

Reproduction from this extracted directory with exact local toolchain:

```
tsc --target ES2022 --module NodeNext --moduleResolution NodeNext --strict --noUncheckedIndexedAccess --exactOptionalPropertyTypes --lib ES2022,DOM --skipLibCheck --noEmitOnError --outDir build index.ts
python3 oracle.py --output oracle.jsonl
node compare.mjs
SND_ARITHMETIC_MODULE="file://$PWD/build/index.js" SND_ORACLE_VECTORS="$PWD/oracle.jsonl" node --test arithmetic.test.mjs
SND_ARITHMETIC_MODULE="file://$PWD/build/index.js" node benchmark.mjs 100000
python3 verifier_extra.py > verifier-extra.jsonl
node verifier-extra.mjs
```

## Residual gates
Full clean Git checkout replay and clean npm ci BLOCKED/NOT RUN (DNS); full project typecheck, contract typecheck and baseline smoke are Engineering-reported in validated archive, not independently rerun here. No actual PostgreSQL round trip; AR10 pre-cast portion only. Raw JSON depth, duplicate keys, envelope validation and hostile JS objects outside typed arithmetic API; must be handled upstream before public endpoints. 1024-digit temporary bound unreachable with valid current 256-digit operands; no runtime coverage claimed for that branch. Limits candidate technical profile only, not historical/product limits. No production security, policy activation, posting, rice workflow, integration or A01-A12 product acceptance. No new CI, merge, deploy, SQL change, Codex or real financial data. Original R&D provenance not independently archived in this verification.

No arithmetic defect identified in executed scope. Recommend owner acceptance of isolated A only, with limitations retained; no automatic authorization for B-F. Any documentary closure must preserve exact candidate and evidence and be separately authorized.
