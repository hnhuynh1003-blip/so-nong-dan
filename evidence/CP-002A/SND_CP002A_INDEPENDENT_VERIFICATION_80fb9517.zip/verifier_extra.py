from fractions import Fraction as F
from random import Random
from math import floor, ceil
import json
rng=Random(20261128)
maxval=10**256-1
def wire(x):return {'numerator':str(x.numerator),'denominator':str(x.denominator)}
def expected(x):return {'value':wire(x)} if abs(x.numerator)<=maxval and x.denominator<=maxval else {'error':'RESOURCE_LIMIT'}
def pick(x,q,mode,tie):
 a,b=floor(x/q),ceil(x/q); l,h=a*q,b*q
 if mode=='floor':return l
 if mode=='ceil':return h
 if abs(x-l)<abs(h-x):return l
 if abs(x-l)>abs(h-x):return h
 return {'positive':h,'negative':l,'toward_zero':min((l,h),key=abs),'away_from_zero':max((l,h),key=abs),'even':l if a%2==0 else h}[tie]
def emit(op,args,out):print(json.dumps({'op':op,'args':args,**out},separators=(',',':')))
for i in range(180):
 digits=rng.choice([1,17,77,78,79,127,255,256]); qdigits=rng.choice([1,79,128,255,256]); n=10**digits; m=10**qdigits
 x=F(rng.randrange(-n+1,n),rng.randrange(1,n)); q=F(rng.randrange(1,m),rng.randrange(1,m))
 for mode,tie in [('floor',None),('ceil',None)]+[('nearest',t) for t in ['positive','negative','toward_zero','away_from_zero','even']]:
  opts={'method':mode,'quantum':wire(q)}
  if tie:opts['tie']=tie
  emit('round',[wire(x),opts],expected(pick(x,q,mode,tie)))
for i in range(32):
 # Consecutive large Fibonacci numbers stress gcd rather than easy cancellation.
 a,b=1,1
 for j in range(1100+i*3):a,b=b,a+b
 if b>maxval:continue
 x,y=F(a,b),F(b,a)
 emit('multiply',[wire(x),wire(y)],expected(F(1)))
 emit('divide',[wire(x),wire(x)],expected(F(1)))
 emit('subtract',[wire(x),wire(y)],expected(x-y))
