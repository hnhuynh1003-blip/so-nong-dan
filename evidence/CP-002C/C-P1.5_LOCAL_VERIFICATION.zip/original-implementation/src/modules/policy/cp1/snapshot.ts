/** Single sheet preview evidence and historical fixture replay. No authoritative writes. */
import {CANONICALIZATION_VERSION as CV,CError,fail,record,copyJson,freezeDeep,canonicalDigest,snapshotBodyDigest,sameJson} from './canonical.js';
import {AUTHORITY,fixture,id,digest,time,businessDate,evaluateFixture,validateFixtureSet,POLICY_KEYS,APPROVAL_KEYS,INTERVAL_KEYS,type Policy,type Approval,type Interval} from './fixtures.js';
import {engineIdentity,engineAvailable,engineMatches,invokeVerifiedB,validateVerifiedRational,type EngineIdentity} from './engine.js';
import type {SheetInput,SheetPreview} from '../../rice/calculation/index.js';
export interface SnapshotBody {
  readonly authority:typeof AUTHORITY; readonly kind:'PREVIEW_EVIDENCE'; readonly snapshotSchemaVersion:1;readonly canonicalizationVersion:typeof CV;
  readonly ownerId:string;readonly sheetId:string;readonly revisionId:string;readonly input:SheetInput;readonly inputSha256:string;
  readonly policy:Policy;readonly approval:Approval;readonly effectivity:Interval;readonly evaluationTime:string;readonly businessDate:string;
  readonly engine:EngineIdentity;readonly result:SheetPreview;readonly resultSha256:string;
}
export interface Snapshot extends SnapshotBody {readonly snapshotSha256:string}
const SHEET_KEYS=['ownerId','sheetId','revisionId','groupId','batches','slots','tare','priceVndPerKg','saleScope'] as const;
const BODY_KEYS=['authority','kind','snapshotSchemaVersion','canonicalizationVersion','ownerId','sheetId','revisionId','input','inputSha256','policy','approval','effectivity','evaluationTime','businessDate','engine','result','resultSha256'] as const;
const SNAP_KEYS=[...BODY_KEYS,'snapshotSha256'] as const;
function sheetIds(input:unknown){const r=record(input,SHEET_KEYS);const ownerId=id(r.ownerId),sheetId=id(r.sheetId),revisionId=id(r.revisionId),groupId=r.groupId===null?null:id(r.groupId);if(r.saleScope!=='whole-sheet')fail('WRONG_SCOPE','Single whole-sheet only');return {ownerId,sheetId,revisionId,groupId};}
function equalIds(a:{ownerId:string;sheetId:string;revisionId:string},b:{ownerId:string;sheetId:string;revisionId:string}):boolean{return a.ownerId===b.ownerId&&a.sheetId===b.sheetId&&a.revisionId===b.revisionId;}
export function createSnapshot(set:unknown,request:unknown):Snapshot {
  const q=record(request,['authority','input','evaluationTime','businessDate','requestedPolicyId']);fixture(q.authority);const at=time(q.evaluationTime),date=businessDate(q.businessDate);
  const input=copyJson(q.input,'snapshot') as unknown as SheetInput;const {ownerId,sheetId,revisionId}=sheetIds(input);
  const chosen=evaluateFixture(set,{authority:AUTHORITY,ownerId,evaluationTime:at,requestedPolicyId:q.requestedPolicyId});if(chosen.status!=='ELIGIBLE_FIXTURE')fail(chosen.status,chosen.reason);
  if(!engineAvailable())fail('ENGINE_UNAVAILABLE','No verified fixed adapter');
  const inputSha256=canonicalDigest(input,'snapshot','input').sha256;
  const result=invokeVerifiedB(input);if(!equalIds(result,{ownerId,sheetId,revisionId})||result.status!=='PREVIEW')throw Error('Accepted adapter invariant');
  const resultSha256=canonicalDigest(result,'snapshot','result').sha256;
  const body:SnapshotBody={authority:AUTHORITY,kind:'PREVIEW_EVIDENCE',snapshotSchemaVersion:1,canonicalizationVersion:CV,ownerId,sheetId,revisionId,input,inputSha256,policy:chosen.policy,approval:chosen.approval,effectivity:chosen.effectivity,evaluationTime:at,businessDate:date,engine:engineIdentity(),result,resultSha256};
  const snapshotSha256=snapshotBodyDigest(body).sha256;
  return freezeDeep({...body,snapshotSha256});
}
export type ReplayOutcome={readonly authority:typeof AUTHORITY;readonly status:'VERIFIED';readonly snapshotSha256:string}|{readonly authority:typeof AUTHORITY;readonly status:'MISMATCH'|'UNAVAILABLE';readonly reason:string};
const mismatch=(reason:string):ReplayOutcome=>({authority:AUTHORITY,status:'MISMATCH',reason});
const unavailable=(reason:string):ReplayOutcome=>({authority:AUTHORITY,status:'UNAVAILABLE',reason});
function knownCalcError(e:unknown):e is Error&{code:string}{return e instanceof Error&&(e.name==='RiceError'||e.name==='ArithmeticError')&&typeof (e as Error&{code?:unknown}).code==='string';}
export function replaySnapshot(snapshot:unknown,set:unknown,expectedSnapshotSha256:unknown):ReplayOutcome {
  if(snapshot===null||snapshot===undefined)return unavailable('SNAPSHOT_UNAVAILABLE');
  if(expectedSnapshotSha256===null||expectedSnapshotSha256===undefined)return unavailable('ANCHOR_UNAVAILABLE');
  try{
    const anchor=digest(expectedSnapshotSha256);const r=record(snapshot,SNAP_KEYS);fixture(r.authority);
    if(r.kind!=='PREVIEW_EVIDENCE'||r.snapshotSchemaVersion!==1||r.canonicalizationVersion!==CV)return mismatch('SNAPSHOT_SCHEMA');
    // Validate bounded entire envelope before inspecting nested records; never read accessors or proxies.
    canonicalDigest(snapshot,'snapshot','definition');
    if(r.input===null)return unavailable('INPUT_UNAVAILABLE');
    if(r.policy===null)return unavailable('UNKNOWN_POLICY');
    if(r.approval===null)return unavailable('APPROVAL_UNAVAILABLE');
    if(r.effectivity===null)return unavailable('EFFECTIVITY_UNAVAILABLE');
    if(r.engine===null)return unavailable('ENGINE_UNAVAILABLE');
    const ownDigest=digest(r.snapshotSha256);const body:Record<string,unknown>=Object.create(null);for(const k of BODY_KEYS)body[k]=r[k];
    if(anchor!==ownDigest||snapshotBodyDigest(body).sha256!==ownDigest)return mismatch('SNAPSHOT_HASH');
    const ownerId=id(r.ownerId),sheetId=id(r.sheetId),revisionId=id(r.revisionId),at=time(r.evaluationTime);businessDate(r.businessDate);
    const inputIds=sheetIds(r.input);if(!equalIds(inputIds,{ownerId,sheetId,revisionId}))return mismatch('INPUT_IDENTITY');
    if(canonicalDigest(r.input,'snapshot','input').sha256!==digest(r.inputSha256))return mismatch('INPUT_HASH');
    if(canonicalDigest(r.result,'snapshot','result').sha256!==digest(r.resultSha256))return mismatch('RESULT_HASH');
    if(set===null||set===undefined)return unavailable('EVIDENCE_SET_UNAVAILABLE');
    const policies=validateFixtureSet(set);
    // Snapshot references are compared to external fixture records, not trusted from snapshot alone.
    record(r.policy,POLICY_KEYS);record(r.approval,APPROVAL_KEYS);record(r.effectivity,INTERVAL_KEYS);
    const policy=r.policy as Policy,approval=r.approval as Approval,effect=r.effectivity as Interval;
    const policyId=id(policy.policyId),approvalId=id(approval.approvalId),effectivityId=id(effect.effectivityId);
    if(policy.ownerId!==ownerId||approval.ownerId!==ownerId||effect.ownerId!==ownerId)return mismatch('REFERENCE_OWNER');
    const p=policies.policies.find(x=>x.ownerId===ownerId&&x.policyId===policyId);if(!p)return unavailable('UNKNOWN_POLICY');
    const a=policies.approvals.find(x=>x.ownerId===ownerId&&x.approvalId===approvalId);if(!a)return unavailable('APPROVAL_UNAVAILABLE');
    const e=policies.effectivities.find(x=>x.ownerId===ownerId&&x.effectivityId===effectivityId);if(!e)return unavailable('EFFECTIVITY_UNAVAILABLE');
    if(!sameJson(p,policy)||!sameJson(a,approval)||!sameJson(e,effect))return mismatch('PINNED_REFERENCE');
    const chosen=evaluateFixture(policies,{authority:AUTHORITY,ownerId,evaluationTime:at,requestedPolicyId:policyId});
    if(chosen.status!=='ELIGIBLE_FIXTURE'||chosen.approval.approvalId!==approvalId||chosen.effectivity.effectivityId!==effectivityId)return mismatch('PINNED_EFFECTIVITY');
    if(!engineMatches(r.engine)){
      const pinned=record(r.engine,Object.keys(engineIdentity()));if(typeof pinned.sourceCommit!=='string'||!(/^[a-f0-9]{40}(?![\s\S])/.test(pinned.sourceCommit)))return mismatch('ENGINE_IDENTITY');return pinned.sourceCommit===engineIdentity().sourceCommit?mismatch('ENGINE_IDENTITY'):unavailable('ENGINE_UNAVAILABLE');
    }
    if(!engineAvailable())return unavailable('ENGINE_UNAVAILABLE');
    const calculated=invokeVerifiedB(r.input);if(!equalIds(calculated,{ownerId,sheetId,revisionId})||calculated.status!=='PREVIEW')return mismatch('ENGINE_RESULT_IDENTITY');
    // Check the complete canonical result, not just amount or result digest.
    if(!sameJson(calculated,r.result,'snapshot'))return mismatch('RESULT_FIELDS');
    return {authority:AUTHORITY,status:'VERIFIED',snapshotSha256:ownDigest};
  }catch(e){if(e instanceof CError)return e.code==='ENGINE_UNAVAILABLE'?unavailable(e.code):mismatch(e.code);if(knownCalcError(e))return mismatch(e.code);throw e;}
}
export function historicalUnknown(input:unknown){
  const c=copyJson(input,'policy');const r=record(c,['authority','ownerId','observationId','policy','observedAmount','unit','sourceRef','verificationStatus']);fixture(r.authority);id(r.ownerId);id(r.observationId);id(r.sourceRef);if(r.policy!=='UNKNOWN')fail('DOMAIN','Unknown historical policy required');
  if(r.unit!=='VND'&&r.unit!=='g'&&r.unit!=='kg')fail('DOMAIN','Observation unit');if(r.verificationStatus!=='UNVERIFIED'&&r.verificationStatus!=='VERIFIED'&&r.verificationStatus!=='DISPUTED')fail('DOMAIN','Observation verification status');
  if(r.observedAmount!==null)validateVerifiedRational(r.observedAmount);return c;
}
export type CorrectionOutcome={readonly authority:typeof AUTHORITY;readonly status:'BLOCKED';readonly reason:string}|{readonly authority:typeof AUTHORITY;readonly status:'PLANNED_FIXTURE';readonly originalSnapshotSha256:string;readonly ownerId:string;readonly sheetId:string;readonly originalRevisionId:string;readonly newRevisionId:string;readonly policy:Policy;readonly approval:Approval;readonly effectivity:Interval;readonly engine:EngineIdentity;readonly newInput:SheetInput;readonly newPreview:SheetPreview};
const blocked=(reason:string):CorrectionOutcome=>({authority:AUTHORITY,status:'BLOCKED',reason});
export function planCorrection(snapshot:unknown,set:unknown,expectedSnapshotSha256:unknown,request:unknown):CorrectionOutcome{
  try{
    const q=record(request,['authority','newInput','policyChange']);fixture(q.authority);
    const verified=replaySnapshot(snapshot,set,expectedSnapshotSha256);if(verified.status!=='VERIFIED')return blocked(verified.reason);
    const old=snapshot as Snapshot;const next=copyJson(q.newInput,'snapshot') as unknown as SheetInput;const ids=sheetIds(next);
    if(ids.ownerId!==old.ownerId||ids.sheetId!==old.sheetId||ids.groupId!==old.input.groupId)return blocked('UNSUPPORTED_SCOPE_CHANGE');
    if(ids.revisionId===old.revisionId)return blocked('DISTINCT_REVISION_REQUIRED');
    if(q.policyChange!==null){
      // A separate fixture authorization is required, but C-P1 never executes a changed policy.
      const ch=record(copyJson(q.policyChange,'policy'),['authority','ownerId','sheetId','fromRevisionId','toRevisionId','fromPolicyId','toPolicyId','toDefinitionSha256','approvalId','decisionTime','evidenceRef']);fixture(ch.authority);
      for(const v of [ch.ownerId,ch.sheetId,ch.fromRevisionId,ch.toRevisionId,ch.fromPolicyId,ch.toPolicyId,ch.approvalId,ch.evidenceRef])id(v);digest(ch.toDefinitionSha256);const when=time(ch.decisionTime);
      if(ch.ownerId!==old.ownerId||ch.sheetId!==old.sheetId||ch.fromRevisionId!==old.revisionId||ch.toRevisionId!==ids.revisionId||ch.fromPolicyId!==old.policy.policyId||ch.toPolicyId===old.policy.policyId)return blocked('POLICY_CHANGE_APPROVAL_REQUIRED');
      const s=validateFixtureSet(set),p=s.policies.find(x=>x.ownerId===old.ownerId&&x.policyId===ch.toPolicyId),a=s.approvals.find(x=>x.ownerId===old.ownerId&&x.approvalId===ch.approvalId);
      if(!p||!a||a.policyId!==p.policyId||a.definitionSha256!==p.definitionSha256||p.definitionSha256!==ch.toDefinitionSha256||a.decisionTime>when||old.evaluationTime>when)return blocked('POLICY_CHANGE_APPROVAL_REQUIRED');
      return blocked('POLICY_CHANGE_DEFERRED');
    }
    const newPreview=invokeVerifiedB(next);
    const plan:CorrectionOutcome={authority:AUTHORITY,status:'PLANNED_FIXTURE',originalSnapshotSha256:verified.snapshotSha256,ownerId:old.ownerId,sheetId:old.sheetId,originalRevisionId:old.revisionId,newRevisionId:ids.revisionId,policy:copyJson(old.policy,'policy') as unknown as Policy,approval:copyJson(old.approval,'policy') as unknown as Approval,effectivity:copyJson(old.effectivity,'policy') as unknown as Interval,engine:engineIdentity(),newInput:next,newPreview};
    // The planned response is also bounded, and no input/old snapshot is frozen or mutated.
    canonicalDigest(plan,'snapshot','definition');return freezeDeep(plan);
  }catch(e){if(e instanceof CError)return blocked(e.code);if(knownCalcError(e))return blocked(e.code);throw e;}
}
