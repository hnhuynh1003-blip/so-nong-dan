import assert from 'node:assert/strict';
import {previewRiceSheetBP1 as sheet,previewRiceGroupBP1 as group,RiceError} from './dist/modules/rice/calculation/index.js';
const q=(n,d='1')=>({numerator:String(n),denominator:String(d)});
const base=(revisionId='r1',raw='1500',sid='s')=>{const b={ownerId:'o',sheetId:sid,batchId:'b-'+sid};return {ownerId:'o',sheetId:sid,revisionId,groupId:'g',batches:[b],slots:[{position:'1',bag:{...b,bagId:'bag-'+sid,mode:'gram',raw}}],tare:{method:'proportional',scope:'sheet',bagsPerKg:q(1)},priceVndPerKg:'7351',saleScope:'whole-sheet'}};
const grp=(...sheets)=>({ownerId:'o',groupId:'g',sheets});
const err=(f,c)=>assert.throws(f,e=>e instanceof RiceError&&e.code===c);
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x)}return x};
const a=freeze(base()),b=freeze(base('r2')),c=freeze(base('r2','2500')),x=freeze(sheet(a)),y=sheet(b),z=sheet(c),before=JSON.stringify(x);
const strip=({revisionId,...v})=>v;
assert.equal(x.revisionId,'r1');assert.equal(y.revisionId,'r2');assert.deepEqual(strip(x),strip(y));assert.equal(z.amountVnd.numerator,'14702');assert.equal(x.amountVnd.numerator,'7351');assert.equal(JSON.stringify(x),before);assert.equal(a.slots[0].bag.raw,'1500');
for(const ss of [[a,b],[b,a],[{...a,slots:[],batches:[]},{...b,slots:[],batches:[]}]])err(()=>group(grp(...ss)),'DUPLICATE_ID');
let invalid=0;for(const v of [null,undefined,1,true,[],{}]){err(()=>sheet({...a,revisionId:v}),'INVALID_TYPE');invalid++}for(const v of ['', ' r1','r1\n','-r1','r/1','r\uFF11','r\0']){err(()=>sheet({...a,revisionId:v}),'NONCANONICAL');invalid++}err(()=>sheet({...a,revisionId:'r'.repeat(129)}),'RESOURCE_LIMIT');invalid++;
err(()=>sheet(strip(a)),'INVALID_SHAPE');invalid++;
const hidden={...a};Object.defineProperty(hidden,'revisionId',{enumerable:false});err(()=>sheet(hidden),'INVALID_SHAPE');invalid++;
const access={...a};Object.defineProperty(access,'revisionId',{get(){throw Error('getter executed')},enumerable:true});err(()=>sheet(access),'INVALID_SHAPE');invalid++;
assert.equal(sheet({...a,revisionId:'a'.repeat(128)}).revisionId,'a'.repeat(128));
const other=freeze(base('r2','5000','t'));const g=group(grp(other,c));assert.deepEqual(g.sheets.map(s=>[s.sheetId,s.revisionId]),[['s','r2'],['t','r2']]);assert.deepEqual(group(grp(c,other)),g);for(const v of [x,y,z,g,...g.sheets]){assert.equal(v.status,'PREVIEW');for(const k of ['journal','receipt','snapshot','persistence','mutationId'])assert.ok(!(k in v))}
console.log(JSON.stringify({revisionPreservation:'PASS',numericProjection:'PASS',revisionIsolation:'PASS',duplicateGroupsRejected:3,invalidRevisionRejected:invalid,groupTrace:'PASS',previewOnly:'PASS'}));
