import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
import * as R from './dist/modules/rice/calculation/index.js';
import * as P from '../sndb/dist/modules/rice/calculation/index.js';
const strip=v=>Array.isArray(v)?v.map(strip):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).filter(([k])=>k!=='revisionId').map(([k,x])=>[k,strip(x)])):v;
function run(fn,x){try{return {value:fn(x)}}catch(e){return {error:e.code}}}
let total=0,valid=0,errors=0;
for(const file of ['oracle.jsonl','extra.jsonl']){const rows=readFileSync(file,'utf8').trimEnd().split('\n').map(JSON.parse);for(const c of file==='oracle.jsonl'?rows.slice(0,600):rows){const fn=c.op==='sheet'?'previewRiceSheetBP1':'previewRiceGroupBP1';const a=run(P[fn],strip(c.input)),b=run(R[fn],c.input);assert.deepEqual(a,strip(b),c.id);total++;if(a.error)errors++;else valid++;}}
console.log(JSON.stringify({total,valid,errors,projection:'MATCH'}));
