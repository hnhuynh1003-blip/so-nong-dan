import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {previewRiceSheetBP1 as sheet,previewRiceGroupBP1 as group,RiceError} from './dist/modules/rice/calculation/index.js';
const freeze=x=>{if(x&&typeof x==='object'){for(const y of Object.values(x))freeze(y);Object.freeze(x);}return x;};
let pass=0,err=0,permutation=0,conservation=0;
const n=x=>BigInt(x.numerator),d=x=>BigInt(x.denominator),sameSum=(a,b,c)=> (n(a)*d(b)+n(b)*d(a))*d(c)===n(c)*d(a)*d(b);
const flip=s=>({...s,slots:[...s.slots].reverse(),batches:[...s.batches].reverse()});
for(const c of readFileSync(process.argv[2],'utf8').trimEnd().split('\n').map(JSON.parse)){
 const run=c.op==='sheet'?sheet:group;const before=JSON.stringify(c.input);freeze(c.input);
 if(c.error){assert.throws(()=>run(c.input),e=>e instanceof RiceError&&e.code===c.error,c.id);err++;}
 else{const out=run(c.input);assert.deepEqual(out,c.expected,c.id);pass++;const p=c.op==='sheet'?flip(c.input):{...c.input,sheets:[...c.input.sheets].reverse().map(flip)};assert.deepEqual(run(p),out,c.id);permutation++;
 for(const s of c.op==='sheet'?[out]:out.sheets){assert.equal(s.status,'PREVIEW');assert.ok(!('journal' in s)&&!('receipt' in s));for(const b of [s.columns,s.boards,s.pages]){assert.equal(b.reduce((a,x)=>a+BigInt(x.count),0n),BigInt(s.count));assert.equal(b.reduce((a,x)=>{assert.equal(d(x.grossGram),1n);return a+n(x.grossGram)},0n),n(s.grossGram));}if(s.tareGram!==null){assert.ok(sameSum(s.tareGram,s.physicalNetGram,s.grossGram));assert.ok(sameSum(s.physicalNetGram,s.residualGram,s.settlementGram));assert.deepEqual(s.physicalNetGram,s.commercialNetGram);conservation++;}}}
 assert.equal(JSON.stringify(c.input),before,c.id);
}
console.log(JSON.stringify({pass,err,permutation,conservation,total:pass+err}));
