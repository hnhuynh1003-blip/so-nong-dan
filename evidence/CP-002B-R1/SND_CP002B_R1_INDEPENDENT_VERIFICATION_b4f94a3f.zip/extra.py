import json, random, copy
from fractions import Fraction as F
from oracle import make_sheet,sheet,group
r=random.Random(28112026)
def emit(c):print(json.dumps(c,separators=(',',':'),ensure_ascii=True))
# Mixed batch/mode, sparse, rational tare, prices >2^53, exact rounding near ties.
for i in range(200):
 n=r.randrange(1,45);s=make_sheet(f'x{i}',[r.randrange(5000,99900) for _ in range(n)],F(r.randrange(1,50),r.randrange(1,5)),str(r.randrange(9007199254740993,9007199254999999)),positions=r.sample(range(1,1000001),n))
 b={**s['batches'][0],'batchId':f'b2-{i}'};s['batches'].append(b)
 for j,sl in enumerate(s['slots']):
  if j%3==0:sl['bag'].update(batchId=b['batchId'],mode='three-digit',raw=str(r.randrange(50,999)).zfill(3))
  if j%7==0:sl['bag']=None
 try:expect=sheet(s)
 except ValueError:emit(dict(id=f'x{i}',op='sheet',input=s,error='EXCESS_TARE'))
 else:emit(dict(id=f'x{i}',op='sheet',input=s,expected=expect))
# Exact UI-009 raw sequence, positive tie, zero net, sparse and no rerounding.
nums=[443,446,439,451,444,438,452,447,441,449,445,450,437,442,448,451,444,446,440,447,452,438,445,441,449]
raws=[str(nums[(i+k)%25]) for n,k in [(25,0),(25,8),(13,17)] for i in range(n)]
for sid,raws,ratio,price,mode in [('ui009',raws,F(10),'7350','three-digit'),('near-low',['101499'],F(1),'7351','gram'),('half',['101500'],F(1),'7351','gram'),('near-high',['101501'],F(1),'7351','gram'),('zero',['1000'],F(1),'7351','gram'),('fraction',['50000'],F(3),'7351','gram'),('11bags',['443']*11,F(10),'7351','three-digit')]:
 s=make_sheet(sid,raws,ratio,price,mode=mode);emit(dict(id=sid,op='sheet',input=s,expected=sheet(s)))
for i in range(40):
 ss=[make_sheet(f'ga{i}',[1500],F(1),'7351'),make_sheet(f'gb{i}',[1500],F(1),None if i%2 else '9001'),make_sheet(f'gc{i}',[1000],F(1),'1')];r.shuffle(ss);g=dict(ownerId='o',groupId='g',sheets=ss);emit(dict(id=f'g{i}',op='group',input=g,expected=group(g)))
